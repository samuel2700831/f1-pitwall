"""Prepare a local LangSmith bundle; upload only with an explicit subcommand.

No SDK import, API key lookup or network activity occurs during prepare.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import uuid

from .evals import GOLDEN, RESULTS, METRICS_VERSION, read_dataset, sha, save_report
from .langsmith_config import load_key


def prepare(folder, dataset=GOLDEN):
    folder = Path(folder)
    report = json.loads((folder/'report.json').read_text())
    golden = read_dataset(dataset)
    if report['dataset_sha256'] != sha(golden):
        raise ValueError('Dataset differs from the experiment')
    if not report.get('complete'):
        raise ValueError('Finish the local experiment before preparing a LangSmith bundle')
    dataset_name = golden['dataset_id']+'-'+report['dataset_sha256'][:12]
    examples = []
    for case in golden['cases']:
        examples.append({'id': str(uuid.uuid5(uuid.NAMESPACE_URL, dataset_name+'/'+case['id'])),
                         'inputs': {k: case.get(k) for k in ('id','lap','branch','observed','memory','rival_mode','fault')},
                         'outputs': {k: case.get(k) for k in ('allowed_choices','needs_human','rationale_concepts',
                                                            'stop_loss','position_available','expected_recovery')},
                         'metadata': {k: case[k] for k in ('id','category','split','label_status','label_reason')}})
    approval=report.get('label_approval')
    if approval:
        for example in examples:
            example['metadata'].update(authored_label_status=example['metadata']['label_status'],
                                        label_status='human_approved',approved_on=approval['approved_on'])
    runs = []
    for result in report['results']:
        trace_path = Path(result['trace_file'])
        if trace_path.is_absolute() or '..' in trace_path.parts:
            raise ValueError('Invalid trace path')
        trace = json.loads((folder/trace_path).read_text())
        validate_trace(trace['spans'], result['trace_id'])
        runs.append({'case_id': result['case_id'], 'trace_id': result['trace_id'],
                     'spans': trace['spans'], 'events': trace['events'], 'checks': result['checks']})
    bundle = {'format': 'pitwall-langsmith-v1', 'dataset_name': dataset_name,
              'examples': examples, 'runs': runs, 'summary': report['summary'],
              'metadata': {key: report[key] for key in ('stage','mode','schema_version','dataset_sha256','prompt_sha256',
                                                       'race_data_sha256','rivals_sha256','source_sha256')},
              'upload_status': 'not_uploaded',
              'note': 'Recorded timestamps and hierarchical spans, not reconstructed synthetic durations. '
                      'Local cases have no real LLM calls or token consumption. Two malformed-provider fixtures '
                      'have synthetic LLM spans, explicitly marked in root metadata.'}
    bundle['metadata']['label_approval']=approval
    save_report(bundle, folder/'langsmith-bundle.json')
    return bundle


def validate_trace(spans, root_id):
    seen = {}
    roots = []
    for row in spans:
        if row['id'] in seen:
            raise ValueError('Duplicate span ID')
        start = datetime.fromisoformat(row['start_time'])
        end = datetime.fromisoformat(row['end_time'])
        if end < start or row['latency_ms'] < 0:
            raise ValueError('Invalid span duration')
        parent = row['parent_id']
        if parent is None:
            roots.append(row['id'])
        elif parent not in seen:
            raise ValueError('Missing or unordered parent span')
        else:
            if start < datetime.fromisoformat(seen[parent]['start_time']) or end > datetime.fromisoformat(seen[parent]['end_time']):
                raise ValueError('Child span outside parent duration')
        seen[row['id']] = row
    if roots != [root_id]:
        raise ValueError('Expected exactly one case root')


def build_tree(run, project_name, example_id, client, tree_class):
    """Uses public RunTree APIs. Can be verified with an offline client."""
    nodes = {}
    for row in run['spans']:
        metadata = dict(row['metadata'], local_latency_ms=row['latency_ms'])
        if row['run_type'] == 'llm':
            metadata.update(ls_provider=metadata.get('provider'), ls_model_name=metadata.get('model'))
        extra = {'metadata': metadata}
        if row['usage'] is not None:
            metadata['usage_metadata'] = {k:v for k,v in row['usage'].items() if k!='provider_reported'}
        inputs = row['inputs'] if isinstance(row['inputs'], dict) else {'value': row['inputs']}
        outputs = row['outputs'] if isinstance(row['outputs'], dict) else {'value': row['outputs']}
        start = datetime.fromisoformat(row['start_time'])
        if row['parent_id'] is None:
            tree = tree_class(name=row['name'], id=uuid.UUID(row['id']), run_type=row['run_type'],
                              project_name=project_name, ls_client=client, inputs=inputs,
                              start_time=start, reference_example_id=uuid.UUID(example_id), extra=extra)
        else:
            tree = nodes[row['parent_id']].create_child(row['name'], row['run_type'],
                run_id=uuid.UUID(row['id']), inputs=inputs, start_time=start, extra=extra)
        tree.end(outputs=outputs, error=row['error'], end_time=datetime.fromisoformat(row['end_time']))
        nodes[row['id']] = tree
    for event in run.get('events',[]):
        if event.get('time') and event.get('status')!='ok' and event.get('parent_id') in nodes:
            nodes[event['parent_id']].add_event({'name':event['tool'],'time':event['time'],
                'kwargs':{k:event.get(k) for k in ('role','detail','status')}})
    return nodes[run['trace_id']]


def upload(folder, dataset=GOLDEN):
    """Explicitly sends only a prepared golden experiment to private LangSmith.

    A successful write is insufficient: read back roots, children and metric
    feedback before reporting verified. This path has not run without a key.
    """
    bundle = prepare(folder, dataset)
    key = load_key()
    if not key:
        raise ValueError('Set LANGSMITH_API_KEY privately; never put a key in a command argument')
    endpoint = os.environ.get('LANGSMITH_ENDPOINT', 'https://api.smith.langchain.com').rstrip('/')
    if endpoint not in ('https://api.smith.langchain.com', 'https://eu.api.smith.langchain.com'):
        raise ValueError('Use an official US or EU LangSmith endpoint for this adapter')
    try:
        from langsmith import Client
        from langsmith.run_trees import RunTree
        from langsmith.utils import LangSmithNotFoundError
    except ImportError:
        raise ValueError('Install requirements-evals.txt in Python 3.12+ first') from None
    options = {'api_key': key, 'api_url': endpoint}
    if os.environ.get('LANGSMITH_WORKSPACE_ID'):
        options['workspace_id'] = os.environ['LANGSMITH_WORKSPACE_ID']
    client = Client(**options)
    status = {'status': 'uploading', 'verified': False, 'cases_verified': 0}
    folder = Path(folder)
    try:
        try:
            remote_dataset = client.read_dataset(dataset_name=bundle['dataset_name'])
        except LangSmithNotFoundError:
            remote_dataset = client.create_dataset(bundle['dataset_name'],
                description='F1 Pitwall behavioral golden cases. '+('Owner-approved labels.' if bundle['metadata'].get('label_approval') else 'Author-labeled; human review pending.'),
                metadata={'dataset_sha256': bundle['metadata']['dataset_sha256'],
                          'label_approval':bundle['metadata'].get('label_approval')})
        existing = {str(example.id): example for example in client.list_examples(dataset_id=remote_dataset.id)}
        missing = []
        for example in bundle['examples']:
            old = existing.get(example['id'])
            if old is None:
                missing.append(example)
            elif old.inputs != example['inputs'] or old.outputs != example['outputs']:
                raise ValueError('Remote dataset example differs; use a new dataset version')
        if missing:
            client.create_examples(dataset_id=remote_dataset.id, examples=missing)
        project = client.create_project('f1-pitwall-'+bundle['metadata']['stage']+'-'+uuid.uuid4().hex[:8],
            reference_dataset_id=remote_dataset.id, num_examples=len(bundle['runs']),
            metadata={**bundle['metadata'], 'summary': bundle['summary'],
                      'scope': 'Local contract evaluation' if bundle['metadata']['mode']=='local' else 'Gemini evaluation'})
        status['project_id'] = str(project.id)
        by_case = {example['metadata']['id']: example['id'] for example in bundle['examples']}
        roots = []
        for run in bundle['runs']:
            tree = build_tree(run, project.name, by_case[run['case_id']], client, RunTree)
            tree.post(exclude_child_runs=False)
            roots.append((run, tree))
        client.flush(timeout=60)
        for run, tree in roots:
            for check in run['checks']:
                client.create_feedback(run_id=tree.id, key=check['metric'], score=int(check['passed']),
                    comment=json.dumps({'expected':check['expected'], 'actual':check['actual'],
                                        'failure_mode':check['failure_mode']}),
                    source_info={'evaluator_version':'pitwall-golden-'+METRICS_VERSION,'case_id':run['case_id']})
        for name, metric in bundle['summary']['metrics'].items():
            client.create_feedback(project_id=project.id, key=name, score=metric['rate'],
                comment=str(metric['passed'])+'/'+str(metric['applicable'])+' applicable cases')
        client.update_project(project.id, end_time=datetime.now(timezone.utc))
        client.flush(timeout=60)
        links = []
        for run, tree in roots:
            remote = client.read_run(tree.id, load_child_runs=True)
            def flatten(node):
                return [node]+[item for child in (node.child_runs or []) for item in flatten(child)]
            readback = {str(node.id):node for node in flatten(remote)}
            if set(readback) != {row['id'] for row in run['spans']}:
                raise ValueError('LangSmith child span verification failed')
            for row in run['spans']:
                found = readback[row['id']]
                expected_inputs = row['inputs'] if isinstance(row['inputs'],dict) else {'value':row['inputs']}
                expected_outputs = row['outputs'] if isinstance(row['outputs'],dict) else {'value':row['outputs']}
                if found.inputs != expected_inputs or found.outputs != expected_outputs or found.error != row['error']:
                    raise ValueError('LangSmith input/output/error verification failed')
                if (str(found.parent_run_id) if found.parent_run_id else None) != row['parent_id']:
                    raise ValueError('LangSmith parent relationship verification failed')
                if found.start_time != datetime.fromisoformat(row['start_time']) or found.end_time != datetime.fromisoformat(row['end_time']):
                    raise ValueError('LangSmith timing verification failed')
                if row['usage'] is not None:
                    expected_usage={k:v for k,v in row['usage'].items() if k!='provider_reported'}
                    if (found.extra or {}).get('metadata',{}).get('usage_metadata') != expected_usage:
                        raise ValueError('LangSmith token-usage verification failed')
            feedback = {item.key: item.score for item in client.list_feedback(run_ids=[tree.id])}
            if any(feedback.get(c['metric']) != int(c['passed']) for c in run['checks']):
                raise ValueError('LangSmith evaluator feedback verification failed')
            links.append({'case_id':run['case_id'], 'run_id':str(tree.id), 'url':tree.get_url()})
            status['cases_verified'] += 1
        status.update(status='verified', verified=True, cases=links,
                      dataset_id=str(remote_dataset.id), project_name=project.name)
        save_report(status, folder/'langsmith-status.json')
        return status
    except Exception as error:
        # Do not echo request bodies, headers, connection errors or a secret key.
        status.update(status='incomplete', error_type=type(error).__name__)
        save_report(status, folder/'langsmith-status.json')
        raise ValueError('LangSmith upload was not verified. See the sanitized langsmith-status.json; local results are preserved.') from None
    finally:
        client.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare','upload'))
    parser.add_argument('stage')
    parser.add_argument('--output-dir',type=Path,default=RESULTS)
    args=parser.parse_args()
    if not args.stage or Path(args.stage).name!=args.stage:
        parser.error('Use a simple stage name')
    try:
        result=prepare(args.output_dir/args.stage) if args.action=='prepare' else upload(args.output_dir/args.stage)
        print('Local bundle prepared; nothing uploaded.' if args.action=='prepare' else
              'LangSmith verified '+str(result['cases_verified'])+' cases.')
    except (ValueError,OSError) as error:
        parser.error(str(error))


if __name__=='__main__':main()
