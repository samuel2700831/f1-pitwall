"""Opt-in, dependency-free spans. Ordinary app requests do not record or upload.

The evaluation runner owns the recorder. Native reasoning/signatures and credential
fields are excluded; only explicit tool requests/results and usage are retained.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from functools import wraps
import copy
import time
import uuid

_recorder = ContextVar('pitwall_recorder', default=None)
_parent = ContextVar('pitwall_span_parent', default=None)
PRIVATE = {'api_key', 'authorization', 'x-goog-api-key', 'password', 'database_url',
           'thoughtSignature', 'thought_signature', 'headers', 'access_token'}


def public(value):
    if isinstance(value, dict):
        if value.get('type') in ('gemini_content', 'reasoning') or value.get('thought') is True:
            return {'type': value.get('type', 'private_reasoning'), 'omitted': True}
        return {str(k): '[REDACTED]' if k.lower() in {x.lower() for x in PRIVATE} else public(v)
                for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [public(v) for v in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return type(value).__name__


class Recorder:
    def __init__(self):
        self.spans = []
        self.events = []

    @contextmanager
    def activate(self):
        token = _recorder.set(self)
        parent = _parent.set(None)
        try:
            yield self
        finally:
            _parent.reset(parent)
            _recorder.reset(token)


@contextmanager
def span(name, kind='chain', inputs=None, metadata=None):
    recorder = _recorder.get()
    if recorder is None:
        yield {}
        return
    row = {'id': str(uuid.uuid4()), 'parent_id': _parent.get(), 'name': name,
           'run_type': kind, 'inputs': public(copy.deepcopy(inputs)),
           'metadata': public(metadata or {}), 'start_time': datetime.now(timezone.utc).isoformat(),
           'outputs': None, 'error': None, 'usage': None}
    recorder.spans.append(row)
    started = time.perf_counter()
    token = _parent.set(row['id'])
    try:
        yield row
    except Exception as error:
        # Exception messages may contain a provider body, URL or private input.
        row['error'] = type(error).__name__
        raise
    finally:
        row['end_time'] = datetime.now(timezone.utc).isoformat()
        row['latency_ms'] = round((time.perf_counter() - started) * 1000, 3)
        row['outputs'] = public(row['outputs'])
        _parent.reset(token)


def record_event(event):
    recorder = _recorder.get()
    if recorder is not None:
        recorder.events.append({'parent_id': _parent.get(),'time':datetime.now(timezone.utc).isoformat(),
                                **public(copy.deepcopy(event))})


def traced_tool(method):
    @wraps(method)
    def wrapped(self, name, *args, **kwargs):
        with span(name, 'tool', {'arguments': args[0] if args else {},
                                'role': getattr(self, 'role', 'Strategy Director')}) as row:
            result = method(self, name, *args, **kwargs)
            row['outputs'] = result
            return result
    return wrapped
