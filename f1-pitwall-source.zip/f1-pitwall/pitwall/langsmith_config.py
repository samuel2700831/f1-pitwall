"""Private local LangSmith credential setup. Never sends or prints the key."""
import getpass
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
from .data import ROOT

KEY_PATH=ROOT/'.local/langsmith.json'


def save_key(key,path=KEY_PATH):
    if not isinstance(key,str) or not 20<=len(key)<=512 or not key.isascii() or any(c.isspace() for c in key) or key.startswith(('sk-','AIza')):
        raise ValueError('Paste the full LangSmith API key, not a Gemini or OpenAI key.')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    tmp=None
    try:
        with tempfile.NamedTemporaryFile('w',dir=path.parent,delete=False) as file:
            tmp=Path(file.name);os.chmod(tmp,0o600)
            json.dump({'api_key':key},file);file.write('\n')
        tmp.replace(path)
    finally:
        if tmp and tmp.exists():tmp.unlink()


def load_key(path=KEY_PATH):
    key=os.environ.get('LANGSMITH_API_KEY','').strip()
    if key:return key
    try:
        fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
        with os.fdopen(fd) as file:
            info=os.fstat(file.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_mode&0o077 or (hasattr(os,'getuid') and info.st_uid!=os.getuid()):return ''
            record=json.load(file)
        key=record.get('api_key','')
        return key if isinstance(key,str) else ''
    except (OSError,ValueError,AttributeError):return ''


def main():
    if not sys.stdin.isatty():
        print('Open Configure LangSmith.command yourself to enter the key privately.');return 1
    print('F1 Pitwall — Configure LangSmith\nPaste your LangSmith key below. Characters will stay hidden.\nThe key stays in an owner-only, Git-ignored local file.\n')
    try:
        save_key(getpass.getpass('LangSmith API key (hidden): ').strip())
        print('\nSaved. Return to Codex and reply “LangSmith key saved.”')
        input('\nPress Return to close. ')
        return 0
    except (EOFError,KeyboardInterrupt):
        print('\nSetup canceled.');return 1
    except ValueError as error:
        print(str(error));input('Press Return to close. ');return 1


if __name__=='__main__':raise SystemExit(main())
