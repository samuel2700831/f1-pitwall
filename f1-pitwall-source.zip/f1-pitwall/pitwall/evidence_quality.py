"""Explicit evidence-quality gates, separate from strategy cost assumptions."""
from .simulation import COMPOUNDS


def quality_issues(observed, branch):
    issues = []
    if observed.get('condition') == 'unknown':
        issues.append('Weather condition is unknown; review missing weather evidence.')
    if 'weather_age_seconds' in observed:
        age = observed['weather_age_seconds']
        if age is None:
            issues.append('Weather evidence is unavailable.')
        elif age > 300:
            issues.append('Weather evidence is stale (more than five minutes old).')
    if observed.get('race_control') == 'UNKNOWN':
        issues.append('Race control is unknown; do not assume green conditions.')
    if branch.get('compound') not in COMPOUNDS:
        issues.append('The current tyre compound is unknown; a human must select it.')
    # Omitted fields in small library fixtures are not an assertion of missing
    # feed data. A real replay always supplies an explicit rivals object.
    if 'rivals' in observed:
        rivals = observed['rivals']
        if not rivals.get('available') or not rivals.get('drivers'):
            issues.append('Rival timing is unavailable; do not rely on a full-field rank.')
        elif len(rivals['drivers']) < 19:
            issues.append('Rival timing is partial; the full-field order is incomplete.')
    return issues
