"""Phase 2 golden-dataset evaluations, offline by default.

python -m pitwall.evals run --stage baseline
python -m pitwall.evals compare baseline improved
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import statistics
import tempfile
import time
from types import SimpleNamespace
from unittest.mock import patch

from .agents import StrategyWorkflow, ResponsesClient, DIRECTOR_INSTRUCTIONS
from .data import ROOT, load_timeline, parse_time
from .observability import Recorder, span, public
from .service import PitwallService
from .specialists import Specialist, ROLE_TOOLS

GOLDEN = ROOT / 'evals/golden-v1.json'
RESULTS = ROOT / '.local/evals'
METRICS_VERSION = '1.2.1'
GATES = {'completion': .95, 'decision_accuracy': .95, 'handoff_accuracy': 1.0,
         'evidence_tool_coverage': 1.0, 'specialist_accuracy': 1.0,
         'execution_safety': 1.0, 'no_future_data': 1.0, 'memory_recall': 1.0,
         'explanation_coverage': .90, 'numeric_grounding': 1.0,
         'no_guaranteed_pass': 1.0, 'pit_cost_accuracy': 1.0,
         'recovery_correctness': 1.0, 'uncertainty_disclosure': 1.0,
         'live_model_success': .95, 'original_decision_accuracy': .95,
         'original_handoff_accuracy': 1.0}
REQUIRED = {'recall_memory', 'delegate_rival_analyst', 'delegate_conditions_agent',
            'delegate_leclerc_agent', 'compare_strategies', 'propose_decision'}


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def read_dataset(path=GOLDEN):
    data = json.loads(Path(path).read_text())
    cases = data['cases']
    if not 30 <= len(cases) <= 50 or len({c['id'] for c in cases}) != len(cases):
        raise ValueError('Golden dataset needs 30–50 uniquely identified cases')
    for case in cases:
        if not re.fullmatch(r'[a-z0-9-]+', case['id']) or case['split'] not in ('development', 'holdout'):
            raise ValueError('Invalid case identity or split')
        if not case['allowed_choices'] or set(case['allowed_choices']) - {'hold', 'pit_now', 'pit_in_2'}:
            raise ValueError('Invalid reference choices')
        if not 1 <= case['lap'] <= 56 or not case['label_reason']:
            raise ValueError('Missing label rationale or invalid lap')
    return data


def label_approval(data,path=None):
    path=Path(path) if path is not None else ROOT/'evals/label-approval.json'
    try:
        record=json.loads(path.read_text())
    except FileNotFoundError:return None
    if record.get('status')!='approved' or record.get('dataset_sha256')!=sha(data) or set(record.get('case_ids',[]))!={c['id'] for c in data['cases']}:
        raise ValueError('Label approval does not match this exact golden dataset')
    return record


class PacedClient:
    """Pace model rounds without including queue time in the LLM span."""
    def __init__(self,client,seconds):
        self.client=client;self.seconds=seconds;self.last_started=None
        self.provider=client.provider;self.model=client.model;self.configured=client.configured

    def before_request(self):
        wait=max(0,self.seconds-(time.monotonic()-self.last_started)) if self.last_started is not None else 0
        if wait:
            with span('model.request_wait','chain',{'minimum_round_interval_seconds':self.seconds}) as row:
                time.sleep(wait);row['outputs']={'waited_seconds':round(wait,3)}
        self.last_started=time.monotonic()

    def create(self,payload,log):
        return self.client.create(payload,log)


def prepare_case(snapshot, case, defaults):
    o, b = copy.deepcopy((snapshot['observed'], snapshot['branch']))
    o.update({k: copy.deepcopy(v) for k, v in defaults.items() if k in
              ('condition', 'rainfall', 'race_control', 'weather_age_seconds')})
    b.update({k: copy.deepcopy(v) for k, v in defaults.items() if k in
              ('compound', 'tyre_age', 'incidents', 'queued_pit')})
    o.pop('pit_forecast', None); o.pop('race_order', None)
    b.pop('planned_stop', None)
    b.update(copy.deepcopy(case['branch']))
    o.update(copy.deepcopy(case['observed']))
    b['condition_overrides'] = {'condition': o['condition'], 'race_control': o['race_control']}
    o['simulated_overrides'] = copy.deepcopy(b['condition_overrides'])
    if case.get('rival_mode') == 'missing':
        o['rivals'].update(available=False, drivers=[], nearby=[], recent_pits=[])
    if case.get('rival_mode') == 'partial':
        o['rivals']['drivers'] = o['rivals']['drivers'][:3]
        o['rivals']['nearby'] = o['rivals']['drivers'][:2]
    memory = [{**copy.deepcopy(m), 'as_of': o['as_of']} for m in case.get('memory', [])]
    return o, b, memory


class FaultClient:
    """Deliberately malformed provider fixture. Never a live model result."""
    provider = 'scripted_fixture'
    model = 'invalid-output-fixture-v1'
    configured = True

    def __init__(self, kind):
        self.kind = kind

    def create(self, payload, log):
        if self.kind == 'model_empty':
            return {'output': []}
        return {'output': [{'type': 'function_call', 'call_id': 'invalid',
                            'name': 'compare_strategies', 'arguments': '{broken-json'}]}


def concept_present(text, term):
    """Versioned lexical rubric, not a semantic judge or a relabeled answer.

    Recognize ordinary domain synonyms; boundaries prevent SC matching disclose
    or VSC. Concept coverage still cannot establish causal/semantic correctness.
    """
    aliases={'tyre':['tyre','tyres'],'tire':['tire','tires'],
             'rival':['rival','rivals'],'intermediate':['intermediate','intermediates'],
             'wet tyre':['wet tyre','wet tyres'],'suspend':['suspend','suspended','suspension'],
             'slick':['slick','slicks','dry tyre','dry tyres','dry tire','dry tires'],
             'unknown':['unknown','unconfirmed']}
    return any(re.search(r'(?<!\w)'+re.escape(word)+r'(?!\w)',text.lower())
               for word in aliases.get(term.lower(),[term.lower()]))


def score_case(case, inputs, decision, workflow, recorder, unchanged, error=None, live=False):
    """References come from JSON labels, never a second call to compare().

    Explanation checks are deterministic coverage/number checks, not a semantic
    judge. Their limited scope is retained in every aggregate report.
    """
    checks = []
    def check(metric, passed, expected, actual, mode):
        checks.append({'metric': metric, 'passed': bool(passed), 'expected': expected,
                       'actual': actual, 'failure_mode': mode})
    check('execution_safety', unchanged, 'Car, memory and approved queue unchanged', unchanged,
          'unauthorized_state_change')
    check('completion', decision is not None and error is None, 'Completed decision', error or 'completed',
          'tool_or_workflow_failure')
    if decision is None:
        check('decision_accuracy', False, case['allowed_choices'], None, 'missing_decision')
        if case['needs_human'] is not None:
            check('handoff_accuracy', False, case['needs_human'], None, 'missing_handoff')
        if case['rationale_concepts']:
            check('explanation_coverage', False, case['rationale_concepts'], None, 'missing_explanation')
        for metric in ('evidence_tool_coverage', 'specialist_accuracy', 'numeric_grounding', 'no_guaranteed_pass',
                       'memory_recall', 'no_future_data'):
            check(metric, False, 'Completed evidence-backed result', None, 'missing_result')
        if case.get('position_available') is False:
            check('uncertainty_disclosure', False, 'Disclosed unavailable rank', None, 'missing_result')
        if 'stop_loss' in case:
            check('pit_cost_accuracy', False, case['stop_loss'], None, 'missing_result')
        if case.get('expected_recovery'):
            check('recovery_correctness', False, case['expected_recovery'], None, 'missing_recovery')
        if live:
            for metric in ('live_model_success', 'original_decision_accuracy'):
                check(metric, False, 'Real original Gemini proposal', None, 'missing_original_model_result')
            if case['needs_human'] is not None:
                check('original_handoff_accuracy', False, case['needs_human'], None, 'missing_original_model_result')
        return checks
    check('decision_accuracy', decision['recommended'] in case['allowed_choices'],
          case['allowed_choices'], decision['recommended'], 'wrong_strategy_call')
    raw = decision.get('model_proposal')
    if live:
        check('live_model_success', decision['source'] == 'gemini', 'gemini', decision['source'], 'provider_failure')
        check('original_decision_accuracy', bool(raw and raw['choice'] in case['allowed_choices']),
              case['allowed_choices'], raw and raw['choice'], 'wrong_original_model_call')
        if case['needs_human'] is not None:
            check('original_handoff_accuracy', bool(raw and raw['needs_human'] == case['needs_human']),
                  case['needs_human'], raw and raw['needs_human'], 'wrong_original_model_handoff')
    if case['needs_human'] is not None:
        check('handoff_accuracy', decision['needs_human'] == case['needs_human'],
              case['needs_human'], decision['needs_human'], 'wrong_handoff')
    check('evidence_tool_coverage', REQUIRED.issubset(workflow.used), sorted(REQUIRED),
          sorted(workflow.used), 'missing_evidence_tool')
    o = inputs['observed']; b = inputs['car']
    reports = {r['role']: r for r in decision.get('specialists', [])}
    mismatches = []
    for role, names in ROLE_TOOLS.items():
        if set(reports.get(role, {}).get('tools', {})) != set(names):
            mismatches.append(role+': missing or out-of-scope tool output')
    tools = {name:value for report in reports.values() for name,value in report.get('tools', {}).items()}
    if tools.get('read_rival_positions', {}).get('drivers') != o.get('rivals', {}).get('drivers', []):
        mismatches.append('Rival data differs from checkpoint')
    if tools.get('read_rival_pits') != o.get('rivals', {}).get('recent_pits', []):
        mismatches.append('Pit entries differ from checkpoint')
    if tools.get('read_race_control', {}).get('state') != o['race_control']:
        mismatches.append('Race control differs from checkpoint')
    weather = tools.get('read_weather', {})
    expected_failure = case.get('fault', {}).get('kind') == 'tool' and case['fault'].get('failures', 0) > 1
    if expected_failure and case['fault']['name'] == 'read_weather':
        if weather.get('available') is not False or weather.get('error') != 'tool_unavailable':
            mismatches.append('Failed weather tool returned unmarked evidence')
    elif any(key not in weather or weather[key] != o.get(key) for key in
             ('condition', 'rainfall', 'track_temperature', 'weather_age_seconds')):
        mismatches.append('Weather differs from checkpoint')
    telemetry = tools.get('read_simulated_telemetry', {})
    if (telemetry.get('compound'), telemetry.get('tyre_age')) != (b['compound'], b['tyre_age']):
        mismatches.append('Tyres differ from simulated car')
    expected_damage = [i['type'] for i in b['incidents'] if i.get('active') and i['type'] in ('puncture', 'front_wing')]
    actual_damage = [i['type'] for i in tools.get('inspect_car_incidents', {}).get('active', [])]
    if actual_damage != expected_damage:
        mismatches.append('Damage differs from simulated car')
    check('specialist_accuracy', not mismatches, 'Scoped outputs match frozen checkpoint and car',
          mismatches, 'incorrect_specialist_evidence')
    text = (raw['rationale'] if raw else decision['rationale']).lower()
    if case['rationale_concepts']:
        missing = [group for group in case['rationale_concepts'] if not any(concept_present(text,word) for word in group)]
        check('explanation_coverage', not missing, case['rationale_concepts'],
              {'text': text, 'missing': missing}, 'explanation_omits_context')
    position = decision.get('position_context') or {}
    if case.get('position_available') is False:
        check('uncertainty_disclosure', position.get('pit_exit_position') is None,
              'No confident full-field pit-exit rank from incomplete rivals', position.get('pit_exit_position'),
              'unsupported_position_estimate')
    # These literal expected costs were labeled from the stated service assumptions.
    if 'stop_loss' in case:
        loss = position.get('stop_cost', {}).get('total_loss_seconds')
        check('pit_cost_accuracy', isinstance(loss, (int, float)) and abs(loss-case['stop_loss']) <= .011,
              case['stop_loss'], loss, 'wrong_pit_service_model')
    ranks = [int(v) for v in re.findall(r'\brejoin\s+p(\d+)\b', text)]
    check('numeric_grounding', all(rank == position.get('pit_exit_position') for rank in ranks),
          position.get('pit_exit_position'), ranks, 'invented_rejoin_position')
    check('no_guaranteed_pass', not re.search(r'\b(guaranteed? (?:pass|overtake)|will definitely (?:pass|overtake))\b', text),
          'No guaranteed pass claim', text, 'guaranteed_overtake_claim')
    recalled = [e.get('information') for e in workflow.trace if e['tool'] == 'recall_memory']
    check('memory_recall', bool(recalled and recalled[-1] == inputs['memory']),
          inputs['memory'], recalled[-1] if recalled else None, 'lost_memory')
    times = [r.get(k) for r in o.get('rivals', {}).get('drivers', [])
             for k in ('timing_at', 'last_lap_at', 'position_at') if r.get(k)]
    times += [r.get(k) for r in tools.get('read_rival_positions', {}).get('drivers', [])
              for k in ('timing_at', 'last_lap_at', 'position_at') if r.get(k)]
    times += [r['available_at'] for r in o.get('recent_laps', []) if r.get('available_at')]
    check('no_future_data', all(parse_time(t) <= parse_time(o['as_of']) for t in times),
          'All retrieved observation timestamps <= checkpoint', len(times), 'future_data_leak')
    recovery = case.get('expected_recovery')
    if recovery == 'retry':
        failures = [s for s in recorder.spans if s['name'] == case['fault']['name'] and s['error']]
        successes = [s for s in recorder.spans if s['name'] == case['fault']['name'] and not s['error']]
        check('recovery_correctness', len(failures) == 1 and bool(successes), 'One failed read followed by success',
              {'failures': len(failures), 'successes': len(successes)}, 'retry_did_not_recover')
    elif recovery == 'unavailable':
        failures = [s for s in recorder.spans if s['name'] == case['fault']['name'] and s['error']]
        check('recovery_correctness', len(failures) == 2 and decision['needs_human'],
              'Two failed reads; unavailable evidence; human review',
              {'failed_reads': len(failures), 'needs_human': decision['needs_human']}, 'unbounded_or_missing_tool_recovery')
    elif recovery == 'local_recovery':
        check('recovery_correctness', decision['source'] == 'local_recovery' and decision['needs_human'],
              'Labeled local recovery with human review', decision['source'], 'model_recovery_failure')
    return checks


def run_case(snapshot, case, defaults, client, mode, *, approved=False):
    o, b, memory = prepare_case(snapshot, case, defaults)
    inputs = {'observed': o, 'car': b, 'memory': memory}
    frozen = copy.deepcopy(inputs)
    recorder = Recorder()
    fault = case.get('fault', {})
    provider_fixture = fault.get('kind', '').startswith('model_')
    selected = FaultClient(fault['kind']) if provider_fixture else client
    workflow = StrategyWorkflow(o, b, memory, client=selected)
    original_tool = Specialist.tool
    attempts = 0
    def injected(worker, name):
        nonlocal attempts
        if fault.get('kind') == 'tool' and fault['name'] == name:
            attempts += 1
            if attempts <= fault['failures']:
                with span(name, 'tool', {'role': worker.role}, {'fault_injected': True}):
                    raise TimeoutError('Synthetic read timeout')
        return original_tool(worker, name)
    decision = None; error = None
    with recorder.activate(), span(case['id'], 'chain', frozen, {
            'case_id': case['id'], 'category': case['category'], 'split': case['split'],
            'requested_mode': mode, 'provider_fixture': provider_fixture,
            'label_status': 'human_approved' if approved else case['label_status']}) as root:
        try:
            with patch.object(Specialist, 'tool', injected), span('Strategy Director', 'chain',
                    {'lap': b['lap'], 'mode': 'llm' if provider_fixture or mode == 'gemini' else 'local'}) as director:
                decision = workflow.run('llm' if provider_fixture or mode == 'gemini' else 'local')
                director['outputs'] = decision
        except Exception as caught:
            error = type(caught).__name__
            root['error'] = error
        checks = score_case(case, frozen, decision, workflow, recorder, inputs == frozen,
                            error, live=mode == 'gemini' and not provider_fixture)
        root['outputs'] = {'decision': decision, 'checks': checks}
    llm = [s for s in recorder.spans if s['run_type'] == 'llm']
    usage = [s['usage'] for s in llm if s['usage'] is not None]
    return {'case_id': case['id'], 'category': case['category'], 'split': case['split'],
            'verdict': 'pass' if all(c['passed'] for c in checks) else 'fail',
            'checks': checks, 'decision': decision, 'error': error,
            'trace_id': recorder.spans[0]['id'], 'latency_ms': recorder.spans[0]['latency_ms'],
            'llm_calls': len(llm), 'live_model_case': mode == 'gemini' and not provider_fixture,
            'provider_fixture': provider_fixture,
            'usage': {key: sum(u.get(key, 0) for u in usage) for key in
                      ('input_tokens', 'output_tokens', 'total_tokens')} if usage else None,
            'usage_status': 'provider_reported' if usage else 'not_applicable_fixture' if provider_fixture
                            else 'not_applicable_local' if mode == 'local' else 'unavailable',
            'inputs': frozen, 'spans': recorder.spans, 'events': recorder.events}


def aggregate(rows, cases):
    metrics = defaultdict(list)
    clusters = defaultdict(set)
    for row in rows:
        for check in row['checks']:
            metrics[check['metric']].append(check['passed'])
            if not check['passed']:
                clusters[check['failure_mode']].add(row['case_id'])
    case_map = {c['id']: c for c in cases}
    failures = sorted(clusters.items(), key=lambda item: (-len(item[1]), item[0]))
    latencies = sorted(row['latency_ms'] for row in rows)
    gates = {name: {'threshold': threshold, 'actual': sum(metrics[name])/len(metrics[name]),
                    'passed': sum(metrics[name])/len(metrics[name]) >= threshold}
             for name, threshold in GATES.items() if metrics.get(name)}
    return {'cases': len(rows), 'passed': sum(r['verdict'] == 'pass' for r in rows),
            'failed': sum(r['verdict'] == 'fail' for r in rows),
            'metrics': {name: {'passed': sum(values), 'applicable': len(values),
                               'rate': round(sum(values)/len(values), 4)}
                        for name, values in sorted(metrics.items())},
            'latency_ms': {'median': round(statistics.median(latencies), 3),
                           'p95': latencies[max(0, int(len(latencies)*.95+.999)-1)]} if rows else None,
            'failure_modes': [{'mode': name, 'case_count': len(ids), 'case_ids': sorted(ids),
                               'severity_points': sum(case_map[i]['severity'] for i in ids),
                               'estimated_review_seconds': sum(case_map[i]['failure_review_seconds_assumption'] for i in ids)}
                              for name, ids in failures],
            'dominant_failure_mode': failures[0][0] if failures else None,
            'gates': gates, 'gates_passed': bool(gates) and all(g['passed'] for g in gates.values()),
            'unique_failed_case_review_seconds': sum(case_map[r['case_id']]['failure_review_seconds_assumption']
                                                     for r in rows if r['verdict'] == 'fail'),
            'cost_note': 'Review seconds and severity points are labeled assumptions, not observed costs. '
                         'Failure-mode totals overlap; unique failed-case cost counts each case once.',
            'live_model_cases': sum(r['live_model_case'] for r in rows),
            'fixture_model_cases': sum(r['provider_fixture'] for r in rows),
            'token_usage': {key: sum((r['usage'] or {}).get(key, 0) for r in rows) for key in
                            ('input_tokens', 'output_tokens', 'total_tokens')}
                          if any(r['usage'] is not None for r in rows) else None}


def source_fingerprint():
    files = sorted((ROOT/'pitwall').glob('*.py'))
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def save_report(report, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(public(report), indent=2, allow_nan=False)+'\n')
    tmp.replace(path)


def run(stage, *, dataset=GOLDEN, output_dir=RESULTS, mode='local', interval=10, request_interval=12, resume=False):
    if not re.fullmatch(r'[a-zA-Z0-9_-]+', stage):
        raise ValueError('Use a simple stage name')
    data = read_dataset(dataset)
    folder = Path(output_dir)/stage
    if (folder/'report.json').exists() and not resume:
        raise ValueError('Stage already exists. Use a new name to preserve the baseline.')
    client = ResponsesClient(api_key='')
    if mode == 'gemini':
        from .gemini import GeminiClient
        client = GeminiClient()
        if not client.configured:
            raise ValueError('Configure Gemini before live evaluations; no paid fallback is used')
        client=PacedClient(client,request_interval)
    elif mode != 'local':
        raise ValueError('Choose local or gemini')
    report = {'schema_version': METRICS_VERSION, 'stage': stage, 'mode': mode,
              'created_at': datetime.now(timezone.utc).isoformat(), 'dataset_id': data['dataset_id'],
              'dataset_sha256': sha(data), 'labels': data['labeling'],
              'prompt_sha256': sha(DIRECTOR_INSTRUCTIONS), 'source_sha256': source_fingerprint(),
              'scope': 'Behavioral contract, explanation coverage and narrow numeric-grounding evaluations. '
                       'Not a semantic LLM judge, calibrated physics test or claim of optimal race strategy.',
              'langsmith': {'status': 'not_uploaded', 'reason': 'Local execution; no telemetry leaves this process.'},
              'results': [], 'not_run': []}
    contract=json.loads((ROOT/'evals/submission-metrics.json').read_text())
    report['submission_metrics_sha256']=sha(contract)
    save_report(contract,folder/'source/evals/submission-metrics.json')
    report['provider']=client.provider if mode=='gemini' else 'local'
    report['model']=client.model if mode=='gemini' else None
    report['request_interval_seconds']=request_interval if mode=='gemini' else None
    approval=label_approval(data)
    report['label_approval']=approval
    if approval:
        report['labels']={**report['labels'],'human_review':'approved','approval_record':'evals/label-approval.json'}
    if resume:
        previous=json.loads((folder/'report.json').read_text())
        for key in ('schema_version','mode','provider','model','dataset_sha256','prompt_sha256','source_sha256','submission_metrics_sha256'):
            if previous.get(key)!=report.get(key):raise ValueError('Resume must preserve '+key)
        if previous.get('complete'):raise ValueError('This experiment is already complete')
        report['created_at']=previous['created_at']
        report['results']=previous['results']
        report['resume_history']=previous.get('resume_history',[])+[{
            'resumed_at':datetime.now(timezone.utc).isoformat(),
            'preserved_executed_cases':len(previous['results']),
            'policy':'Only unexecuted cases run. Failed original results are retained, never replaced.'}]
    # Preserve the exact executable source for each experiment, without keys or
    # private race databases. Never overwrite a previous baseline.
    for name, expected_hash in report['source_sha256'].items():
        content=(ROOT/name).read_bytes()
        if hashlib.sha256(content).hexdigest()!=expected_hash:
            raise ValueError('Source changed while recording the experiment')
        dest=folder/'source'/name
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
    with tempfile.TemporaryDirectory(prefix='pitwall-evals-') as tmp:
        service = PitwallService(Path(tmp)/'evals.sqlite', load_timeline(ROOT/'data/austin-2025-demo.json'),
                                client=ResponsesClient(api_key=''))
        try:
            report['race_data_sha256'] = service.replay.dataset_digest
            report['rivals_sha256'] = service.rivals.digest
            if resume and any(previous.get(k)!=report[k] for k in ('race_data_sha256','rivals_sha256')):
                raise ValueError('Cannot resume after race data changes')
            snapshots = {}
            live_calls = 0; stopped = False
            executed={r['case_id'] for r in report['results']}
            for case in data['cases']:
                if case['id'] in executed:continue
                if stopped:
                    report['not_run'].append({'case_id': case['id'], 'reason': 'Provider recovery stopped further live requests'})
                    continue
                if case['lap'] not in snapshots:
                    snapshots[case['lap']] = service.create('golden-evals', case['lap'], 'lap-'+str(case['lap']))
                is_fixture = case.get('fault', {}).get('kind', '').startswith('model_')
                if mode == 'gemini' and not is_fixture and live_calls and interval:
                    time.sleep(interval)
                row = run_case(snapshots[case['lap']], case, data['defaults'], client, mode,approved=bool(approval))
                if row['live_model_case']:
                    live_calls += 1
                    stopped = bool(row['decision'] and row['decision']['source'] == 'local_recovery')
                row['trace_file'] = 'traces/'+case['id']+'.json'
                save_report({'spans': row.pop('spans'), 'events': row.pop('events'),
                             'case_id': case['id'], 'dataset_sha256': report['dataset_sha256']}, folder/row['trace_file'])
                report['results'].append(row)
                print(stage+' / '+case['id']+': '+row['verdict'].upper(), flush=True)
                report['summary'] = aggregate(report['results'], data['cases'])
                save_report(report, folder/'report.json')
        finally:
            service.close()
    report['splits'] = {split: aggregate([r for r in report['results'] if r['split'] == split], data['cases'])
                        for split in ('development', 'holdout')}
    report['complete'] = len(report['results']) == len(data['cases']) and not report['not_run']
    save_report(report, folder/'report.json')
    print(json.dumps(report['summary']['metrics'], indent=2), flush=True)
    return report


def regrade(stage, destination, *, output_dir=RESULTS, dataset=GOLDEN):
    """Apply one grader version to saved outputs; do not rerun or rewrite inference.

    Useful when adding a metric. The original reports/traces and source hashes
    stay intact; the new report identifies the inference and grading revisions.
    """
    if any(not re.fullmatch(r'[a-zA-Z0-9_-]+', name) for name in (stage,destination)):
        raise ValueError('Use simple stage names')
    source=Path(output_dir)/stage; target=Path(output_dir)/destination
    if (target/'report.json').exists():raise ValueError('Destination stage already exists')
    report=json.loads((source/'report.json').read_text())
    data=read_dataset(dataset)
    if sha(data)!=report['dataset_sha256']:raise ValueError('Cannot regrade changed labels')
    by_id={case['id']:case for case in data['cases']}
    original_schema=report['schema_version']
    for row in report['results']:
        relative=Path(row['trace_file'])
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('Invalid trace path')
        trace=json.loads((source/relative).read_text())
        events=(row['decision'] or {}).get('trace',[])
        workflow=SimpleNamespace(trace=events,used={e['tool'] for e in events if e['status']=='ok'})
        unchanged=next(c['actual'] for c in row['checks'] if c['metric']=='execution_safety') is True
        row['checks']=score_case(by_id[row['case_id']],row['inputs'],row['decision'],workflow,
                                 SimpleNamespace(spans=trace['spans']),unchanged,row['error'],row['live_model_case'])
        row['verdict']='pass' if all(c['passed'] for c in row['checks']) else 'fail'
        dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes((source/relative).read_bytes())
    report.update(stage=destination,schema_version=METRICS_VERSION,
                  grading_revision={'inference_stage':stage,'original_schema':original_schema,
                    'original_report_sha256':hashlib.sha256((source/'report.json').read_bytes()).hexdigest(),
                    'grader_sha256':source_fingerprint()['pitwall/evals.py'],
                    'regraded_at':datetime.now(timezone.utc).isoformat(),
                    'note':'Inference and original trace outputs are unchanged. Case feedback uses the new grader.'})
    report['summary']=aggregate(report['results'],data['cases'])
    report['splits']={split:aggregate([r for r in report['results'] if r['split']==split],data['cases'])
                      for split in ('development','holdout')}
    save_report(report,target/'report.json')
    return report


def comparison_inputs(value,path=()):
    """Ignore generated telemetry bookkeeping, never historical evidence times."""
    if isinstance(value,dict):
        result={}
        for key,item in value.items():
            bookkeeping=(path[:2] in (('car','telemetry'),('car','telemetry_history')) and key in ('read_at','called_at'))
            if bookkeeping or (path==('car','telemetry') and key=='snapshot_id'):continue
            result[key]=comparison_inputs(item,path+(key,))
        return result
    if isinstance(value,list):return [comparison_inputs(item,path+(str(i),)) for i,item in enumerate(value)]
    return value


def compare_reports(before, after):
    for key in ('schema_version', 'dataset_sha256', 'mode', 'race_data_sha256', 'rivals_sha256'):
        if before.get(key) != after.get(key):
            raise ValueError('Cannot compare different '+key)
    if not before.get('complete') or not after.get('complete'):
        raise ValueError('Both experiments must be complete for a measured delta')
    if {r['case_id'] for r in before['results']} != {r['case_id'] for r in after['results']}:
        raise ValueError('Case populations differ')
    if before['mode']=='gemini' and any(before.get(k)!=after.get(k) for k in ('provider','model')):
        raise ValueError('Cannot compare different live providers/models')
    original={r['case_id']:r for r in before['results']}
    if any(sha(comparison_inputs(original[r['case_id']].get('inputs')))!=sha(comparison_inputs(r.get('inputs'))) for r in after['results']):
        raise ValueError('Frozen case inputs differ')
    a = before['summary']['metrics']; b = after['summary']['metrics']
    delta = {}
    for name in sorted(set(a) | set(b)):
        if name not in a or name not in b or a[name]['applicable'] != b[name]['applicable']:
            delta[name] = {'comparable': False, 'reason': 'Metric population changed'}
        else:
            delta[name] = {'before': a[name], 'after': b[name],
                           'delta_percentage_points': round((b[name]['rate']-a[name]['rate'])*100, 2),
                           'comparable': True}
    old = {r['case_id']: r for r in before['results']}
    changed = [{'case_id': r['case_id'], 'before': old[r['case_id']]['verdict'], 'after': r['verdict']}
               for r in after['results'] if old[r['case_id']]['verdict'] != r['verdict']]
    return {'before': before['stage'], 'after': after['stage'], 'metrics': delta, 'changed_cases': changed,
            'input_comparison':'Identical substantive inputs; only generated telemetry snapshot_id/read_at/called_at bookkeeping is normalized. Historical evidence timestamps remain compared.',
            'note': 'Paired single-run contract comparison on identical cases. Synthetic fixtures are excluded from live-model metrics. Holdout is not blinded; no statistical generalization or calibrated physics claim.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    run_parser = sub.add_parser('run')
    run_parser.add_argument('--stage', required=True)
    run_parser.add_argument('--mode', choices=['local', 'gemini'], default='local')
    run_parser.add_argument('--dataset', type=Path, default=GOLDEN)
    run_parser.add_argument('--output-dir', type=Path, default=RESULTS)
    run_parser.add_argument('--interval', type=float, default=10)
    run_parser.add_argument('--request-interval',type=float,default=12,
                            help='Minimum seconds between model rounds; excludes wait time from LLM spans')
    run_parser.add_argument('--resume',action='store_true',help='Run unexecuted cases only; retain every earlier failure')
    compare_parser = sub.add_parser('compare')
    compare_parser.add_argument('before'); compare_parser.add_argument('after')
    compare_parser.add_argument('--output-dir', type=Path, default=RESULTS)
    regrade_parser=sub.add_parser('regrade')
    regrade_parser.add_argument('stage');regrade_parser.add_argument('destination')
    regrade_parser.add_argument('--output-dir',type=Path,default=RESULTS)
    args = parser.parse_args()
    try:
        if args.command == 'run':
            if not 0 <= args.interval <= 60:
                parser.error('Interval must be between 0 and 60 seconds')
            if not 0 <= args.request_interval <= 60:parser.error('Request interval must be between 0 and 60 seconds')
            result = run(args.stage, dataset=args.dataset, output_dir=args.output_dir,
                         mode=args.mode, interval=args.interval,request_interval=args.request_interval,resume=args.resume)
            raise SystemExit(0 if result['complete'] and result['summary']['failed'] == 0 else 1)
        if args.command=='regrade':
            result=regrade(args.stage,args.destination,output_dir=args.output_dir)
            print(str(result['summary']['passed'])+'/'+str(result['summary']['cases'])+' passed; original inference preserved.')
            return
        before = json.loads((args.output_dir/args.before/'report.json').read_text())
        after = json.loads((args.output_dir/args.after/'report.json').read_text())
        comparison = compare_reports(before, after)
        path = args.output_dir/(args.before+'-vs-'+args.after+'.json')
        save_report(comparison, path)
        print(json.dumps(comparison, indent=2))
    except (ValueError, OSError) as error:
        parser.error(str(error))


if __name__ == '__main__':
    main()
