"""Optional PostgreSQL persistence for the hosted, single-instance demo.

Only the application's fixed SQL passes through this adapter. Values remain
driver parameters. Local runs continue using the standard-library SQLite path.
"""
from contextlib import contextmanager
import re
import sqlite3
import uuid
from urllib.parse import urlsplit, parse_qs


class Row(dict):
    def __getitem__(self, key):
        return tuple(self.values())[key] if isinstance(key, int) else super().__getitem__(key)


def row_factory(cursor):
    names = [column.name for column in cursor.description] if cursor.description else []
    return lambda values: Row(zip(names, values))


def parameters(sql):
    """Translate internal qmark SQL without changing quoted literal text."""
    result, quote, i = [], None, 0
    while i < len(sql):
        char = sql[i]
        if quote:
            result.append(char)
            if char == quote:
                if i + 1 < len(sql) and sql[i + 1] == quote:
                    result.append(sql[i + 1]); i += 1
                else:
                    quote = None
        elif char in ("'", '"'):
            quote = char; result.append(char)
        else:
            result.append('%s' if char == '?' else char)
        i += 1
    return ''.join(result)


class Connection:
    def __init__(self, connection, token, integrity_error):
        self.connection, self.token = connection, token
        self.integrity_error = integrity_error
        self.locked = False

    def _write_lock(self):
        if self.locked:
            return
        self.connection.execute('SELECT pg_advisory_xact_lock(41811, 1)')
        owner = self.connection.execute('SELECT instance_token FROM pitwall_runtime WHERE id=1').fetchone()
        if owner['instance_token'] != self.token:
            raise RuntimeError('This server instance has been replaced by a newer deployment')
        self.locked = True

    def execute(self, sql, values=()):
        command = sql.strip()
        if command.upper() == 'BEGIN IMMEDIATE':
            self._write_lock()
            return None
        if command.upper() == 'BEGIN':
            return self.connection.execute('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
        pragma = re.fullmatch(r'PRAGMA table_info\((runs|web_jobs)\)', command, re.I)
        if pragma:
            return self.connection.execute('SELECT column_name AS name FROM information_schema.columns WHERE table_schema=current_schema() AND table_name=%s', (pragma[1],))
        if command.split(None, 1)[0].upper() in ('INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER'):
            self._write_lock()
        try:
            return self.connection.execute(parameters(sql), values or None)
        except self.integrity_error as error:
            raise sqlite3.IntegrityError('Database constraint rejected the write') from error

    def executescript(self, script):
        # Schema scripts are fixed CREATE statements without quoted semicolons.
        for statement in script.split(';'):
            if statement.strip():
                self.execute(statement)


class Postgres:
    def __init__(self, url):
        parsed = urlsplit(url)
        if parsed.scheme not in ('postgres', 'postgresql') or not parsed.hostname:
            raise ValueError('DATABASE_URL must be a PostgreSQL connection URL')
        options = parse_qs(parsed.query)
        if options.get('sslmode', ['require'])[-1] not in ('require', 'verify-ca', 'verify-full'):
            raise ValueError('Hosted database connections must require TLS')
        from psycopg import IntegrityError
        from psycopg_pool import ConnectionPool
        self.integrity_error = IntegrityError
        self.token = uuid.uuid4().hex
        self.pool = ConnectionPool(url, min_size=0, max_size=4, timeout=12,
                                   max_idle=60, max_lifetime=600, open=True,
                                   check=ConnectionPool.check_connection,
                                   kwargs={'row_factory': row_factory, 'connect_timeout': 10,
                                           'sslmode': options.get('sslmode', ['require'])[-1],
                                           'prepare_threshold': None,
                                           'options': '-c statement_timeout=12000 -c lock_timeout=10000'})
        # A new deploy fences writes by the old process before recovering jobs.
        # This prevents overlapping clocks during Render's replacement rollout.
        try:
            with self.pool.connection() as connection:
                connection.execute('SELECT pg_advisory_xact_lock(41811, 1)')
                connection.execute('CREATE TABLE IF NOT EXISTS pitwall_runtime (id INTEGER PRIMARY KEY, instance_token TEXT NOT NULL)')
                connection.execute('INSERT INTO pitwall_runtime VALUES (1,%s) ON CONFLICT (id) DO UPDATE SET instance_token=EXCLUDED.instance_token', (self.token,))
        except Exception:
            self.pool.close()
            raise RuntimeError('Hosted database unavailable; local storage fallback is disabled') from None

    @contextmanager
    def connect(self):
        with self.pool.connection() as connection:
            yield Connection(connection, self.token, self.integrity_error)

    def close(self):
        self.pool.close()
