"""Prepare a local LangSmith bundle; upload only with an explicit subcommand.

No SDK import, API key lookup or network activity occurs during prepare.
"""
import argparse
import asyncio
import copy
from datetime import datetime, timezone
import json
import os
import time
from pathlib import Path
import uuid
from urllib.parse import quote

from .evals import GOLDEN, RESULTS, METRICS_VERSION, read_dataset, sha, save_report
from .langsmith_config import load_key


def prepare(folder, dataset=GOLDEN):
    folder = Path(folder)
    report = json.loads((folder/'report.json').read_text())
    golden = read_dataset(dataset)
    if report['dataset_sha256'] != sha(golden):
        raise ValueError('Dataset differs from the experiment')
    if not report.get('complete'):
        raise ValueError('Finish the local experiment before preparing a LangSmith bundle')
    dataset_name = golden['dataset_id']+'-'+report['dataset_sha256'][:12]+'-f1-pitwall'
    examples = []
    for case in golden['cases']:
        examples.append({'id': str(uuid.uuid5(uuid.NAMESPACE_URL, dataset_name+'/'+case['id'])),
                         'inputs': {k: case.get(k) for k in ('id','lap','branch','observed','memory','rival_mode','fault')},
                         'outputs': {k: case.get(k) for k in ('allowed_choices','needs_human','rationale_concepts',
                                                            'stop_loss','position_available','expected_recovery')},
                         'metadata': {k: case[k] for k in ('id','category','split','label_status','label_reason')}})
    approval=report.get('label_approval')
    if approval:
        for example in examples:
            example['metadata'].update(authored_label_status=example['metadata']['label_status'],
                                        label_status='human_approved',approved_on=approval['approved_on'])
    runs = []
    for result in report['results']:
        trace_path = Path(result['trace_file'])
        if trace_path.is_absolute() or '..' in trace_path.parts:
            raise ValueError('Invalid trace path')
        trace = json.loads((folder/trace_path).read_text())
        validate_trace(trace['spans'], result['trace_id'])
        runs.append({'case_id': result['case_id'], 'trace_id': result['trace_id'],
                     'spans': trace['spans'], 'events': trace['events'], 'checks': result['checks'],
                     'grading_context':{'feedback_rubric_version':report['schema_version'],
                                        'grading_revision':report.get('grading_revision')}})
    bundle = {'format': 'pitwall-langsmith-v1', 'dataset_name': dataset_name,
              'examples': examples, 'runs': runs, 'summary': report['summary'],
              'metadata': {key: report[key] for key in ('stage','mode','schema_version','dataset_sha256','prompt_sha256',
                                                       'race_data_sha256','rivals_sha256','source_sha256')},
              'upload_status': 'not_uploaded',
              'note': 'Recorded timestamps and hierarchical spans, not reconstructed synthetic durations. '
                      'Local cases have no real LLM calls or token consumption. Two malformed-provider fixtures '
                      'have synthetic LLM spans, explicitly marked in root metadata.'}
    bundle['metadata']['label_approval']=approval
    bundle['metadata'].update(provider=report.get('provider'),model=report.get('model'),
                              grading_revision=report.get('grading_revision'),
                              submission_metrics_sha256=report.get('submission_metrics_sha256'))
    save_report(bundle, folder/'langsmith-bundle.json')
    return bundle


def validate_trace(spans, root_id):
    seen = {}
    roots = []
    for row in spans:
        if row['id'] in seen:
            raise ValueError('Duplicate span ID')
        start = datetime.fromisoformat(row['start_time'])
        end = datetime.fromisoformat(row['end_time'])
        if end < start or row['latency_ms'] < 0:
            raise ValueError('Invalid span duration')
        parent = row['parent_id']
        if parent is None:
            roots.append(row['id'])
        elif parent not in seen:
            raise ValueError('Missing or unordered parent span')
        else:
            if start < datetime.fromisoformat(seen[parent]['start_time']) or end > datetime.fromisoformat(seen[parent]['end_time']):
                raise ValueError('Child span outside parent duration')
        seen[row['id']] = row
    if roots != [root_id]:
        raise ValueError('Expected exactly one case root')


def build_tree(run, project_name, example_id, client, tree_class):
    """Uses public RunTree APIs. Can be verified with an offline client."""
    nodes = {}
    for row in run['spans']:
        metadata = dict(row['metadata'], local_latency_ms=row['latency_ms'])
        if row['run_type'] == 'llm':
            metadata.update(ls_provider=metadata.get('provider'), ls_model_name=metadata.get('model'))
        extra = {'metadata': metadata}
        if row['usage'] is not None:
            metadata['usage_metadata'] = {k:v for k,v in row['usage'].items() if k!='provider_reported'}
        inputs = row['inputs'] if isinstance(row['inputs'], dict) else {'value': row['inputs']}
        outputs = row['outputs'] if isinstance(row['outputs'], dict) else {'value': row['outputs']}
        start = datetime.fromisoformat(row['start_time'])
        if row['parent_id'] is None:
            tree = tree_class(name=row['name'], id=uuid.UUID(row['id']), run_type=row['run_type'],
                              project_name=project_name, ls_client=client, inputs=inputs,
                              start_time=start, reference_example_id=uuid.UUID(example_id), extra=extra)
        else:
            tree = nodes[row['parent_id']].create_child(row['name'], row['run_type'],
                run_id=uuid.UUID(row['id']), inputs=inputs, start_time=start, extra=extra)
        tree.end(outputs=outputs, error=row['error'], end_time=datetime.fromisoformat(row['end_time']))
        nodes[row['id']] = tree
    for event in run.get('events',[]):
        if event.get('time') and event.get('status')!='ok' and event.get('parent_id') in nodes:
            nodes[event['parent_id']].add_event({'name':event['tool'],'time':event['time'],
                'kwargs':{k:event.get(k) for k in ('role','detail','status')}})
    return nodes[run['trace_id']]


def remap_run(run, project_id):
    """Keep recorded content/times; isolate IDs across repeated cloud exports."""
    result=copy.deepcopy(run)
    mapping={row['id']:str(uuid.uuid5(uuid.UUID(str(project_id)),row['id'])) for row in result['spans']}
    result['trace_id']=mapping[run['trace_id']]
    for row in result['spans']:
        original=row['id']
        row.update(id=mapping[original],parent_id=mapping.get(row['parent_id']))
        row['metadata']['original_local_span_id']=original
        if row['parent_id'] is None and result.get('grading_context'):
            row['metadata'].update(result['grading_context'])
    for event in result.get('events',[]):
        event['parent_id']=mapping.get(event.get('parent_id'))
    return result


def verify_readback(run, remote_rows):
    """Validate SmithDB span payloads, ancestry, timing, tokens and feedback."""
    readback={str(row['id']):row for row in remote_rows}
    if set(readback)!={row['id'] for row in run['spans']}:
        raise ValueError('LangSmith child span verification failed')
    for row in run['spans']:
        found=readback[row['id']]
        inputs=row['inputs'] if isinstance(row['inputs'],dict) else {'value':row['inputs']}
        outputs=row['outputs'] if isinstance(row['outputs'],dict) else {'value':row['outputs']}
        if found.get('inputs')!=inputs or found.get('outputs')!=outputs or found.get('error')!=row['error']:
            raise ValueError('LangSmith input/output/error verification failed')
        # Modern API returns all ancestor IDs; the final dotted-order segment is self.
        order=found.get('dotted_order','').split('.')
        parent=order[-2][-36:] if len(order)>1 else None
        if parent!=row['parent_id']:
            raise ValueError('LangSmith parent relationship verification failed')
        for field in ('start_time','end_time'):
            if datetime.fromisoformat(found[field])!=datetime.fromisoformat(row[field]):
                raise ValueError('LangSmith timing verification failed')
        metadata=(found.get('extra') or {}).get('metadata',{})
        if any(metadata.get(k)!=v for k,v in row['metadata'].items()) or metadata.get('local_latency_ms')!=row['latency_ms']:
            raise ValueError('LangSmith evaluation metadata verification failed')
        if row['usage'] is not None:
            usage={k:v for k,v in row['usage'].items() if k!='provider_reported'}
            if (found.get('extra') or {}).get('metadata',{}).get('usage_metadata')!=usage:
                raise ValueError('LangSmith token-usage verification failed')
    feedback=readback[run['trace_id']].get('feedback_stats') or {}
    if any((feedback.get(c['metric'],{}).get('avg')!=int(c['passed']) or feedback.get(c['metric'],{}).get('n',0)<1) for c in run['checks']):
        raise ValueError('LangSmith evaluator feedback verification failed')


def upload(folder, dataset=GOLDEN):
    """Export a completed experiment and verify via current SmithDB read APIs.

    Agent registration scopes observability resources only; it deploys no app.
    Original inference artifacts remain immutable, including failed verdicts.
    """
    bundle=prepare(folder,dataset)
    key=load_key()
    if not key:
        raise ValueError('Set LANGSMITH_API_KEY privately; never put a key in a command argument')
    endpoint=os.environ.get('LANGSMITH_ENDPOINT','https://api.smith.langchain.com').rstrip('/')
    if endpoint not in ('https://api.smith.langchain.com','https://eu.api.smith.langchain.com'):
        raise ValueError('Use an official US or EU LangSmith endpoint for this adapter')
    try:
        from langsmith import Client
        from langsmith.run_trees import RunTree
        from langsmith.utils import LangSmithNotFoundError
    except ImportError:
        raise ValueError('Install requirements-evals.txt in Python 3.12+ first') from None
    options={'api_key':key,'api_url':endpoint}
    if os.environ.get('LANGSMITH_WORKSPACE_ID'):
        options['workspace_id']=os.environ['LANGSMITH_WORKSPACE_ID']
    client=Client(**options)
    status={'status':'uploading','verified':False,'cases_verified':0}
    folder=Path(folder)
    try:
        try:agent=client.agents.retrieve('f1-pitwall')
        except LangSmithNotFoundError:
            agent=client.agents.create(id='f1-pitwall',source_type='EXTERNAL',name='F1 Pitwall')
        tags=[agent.tag_value_id]
        try:remote_dataset=client.read_dataset(dataset_name=bundle['dataset_name'])
        except LangSmithNotFoundError:
            remote_dataset=client.create_dataset(bundle['dataset_name'],
                description='F1 Pitwall behavioral golden cases. '+('Owner-approved labels.' if bundle['metadata'].get('label_approval') else 'Author-labeled; human review pending.'),
                metadata={'dataset_sha256':bundle['metadata']['dataset_sha256'],
                          'label_approval':bundle['metadata'].get('label_approval')},tag_value_ids=tags)
        existing={str(e.id):e for e in client.list_examples(dataset_id=remote_dataset.id)}
        missing=[]
        for example in bundle['examples']:
            old=existing.get(example['id'])
            if old is None:missing.append(example)
            elif old.inputs!=example['inputs'] or old.outputs!=example['outputs']:
                raise ValueError('Remote dataset example differs; use a new dataset version')
        if missing:client.create_examples(dataset_id=remote_dataset.id,examples=missing)
        project=client.create_project('f1-pitwall-'+bundle['metadata']['stage']+'-'+uuid.uuid4().hex[:8],
            reference_dataset_id=remote_dataset.id,num_examples=len(bundle['runs']),tag_value_ids=tags,
            metadata={**bundle['metadata'],'summary':bundle['summary'],
                      'scope':'Local contract evaluation' if bundle['metadata']['mode']=='local' else '38 live Gemini cases + 2 explicitly synthetic recovery fixtures'})
        status.update(project_id=str(project.id),dataset_id=str(remote_dataset.id),project_name=project.name)
        save_report(status,folder/'langsmith-status.json')
        by_case={e['metadata']['id']:e['id'] for e in bundle['examples']}
        roots=[]
        for original in bundle['runs']:
            run=remap_run(original,project.id)
            tree=build_tree(run,project.name,by_case[run['case_id']],client,RunTree)
            tree.post(exclude_child_runs=False);roots.append((run,tree))
        client.flush(timeout=60)
        def send_feedback(item):
            run,tree,check=item
            client.create_feedback(run_id=tree.id,trace_id=tree.id,session_id=project.id,start_time=tree.start_time,
                feedback_id=uuid.uuid5(tree.id,check['metric']),
                key=check['metric'],score=int(check['passed']),
                comment=json.dumps({'expected':check['expected'],'actual':check['actual'],'failure_mode':check['failure_mode']}),
                source_info={'evaluator_version':'pitwall-golden-'+bundle['metadata']['schema_version'],'case_id':run['case_id']})
        for run,tree in roots:
            for check in run['checks']:send_feedback((run,tree,check))
        client.update_project(project.id,end_time=datetime.now(timezone.utc))
        client.flush(timeout=60)
        return verify_uploaded(folder,client=client)
    except Exception as error:
        status.update(status='incomplete',error_type=type(error).__name__)
        save_report(status,folder/'langsmith-status.json')
        raise ValueError('LangSmith upload was not verified. See the sanitized langsmith-status.json; local results are preserved.') from None
    finally:client.close()


def verify_uploaded(folder,client=None):
    """Read-only retry of an existing export; never rerun inference or upload."""
    folder=Path(folder)
    bundle=json.loads((folder/'langsmith-bundle.json').read_text())
    status=json.loads((folder/'langsmith-status.json').read_text())
    owned=client is None
    if owned:
        key=load_key()
        if not key:raise ValueError('Set LANGSMITH_API_KEY privately; never put a key in a command argument')
        endpoint=os.environ.get('LANGSMITH_ENDPOINT','https://api.smith.langchain.com').rstrip('/')
        if endpoint not in ('https://api.smith.langchain.com','https://eu.api.smith.langchain.com'):
            raise ValueError('Use an official US or EU LangSmith endpoint for this adapter')
        from langsmith import Client
        options={'api_key':key,'api_url':endpoint}
        if os.environ.get('LANGSMITH_WORKSPACE_ID'):options['workspace_id']=os.environ['LANGSMITH_WORKSPACE_ID']
        client=Client(**options)
    try:
        project=client.read_project(project_id=status['project_id'])
        host='https://'+('eu.' if 'eu.api.' in client.api_url else '')+'smith.langchain.com'
        base=f'{host}/o/{project.tenant_id}/a/f1-pitwall/datasets/{status["dataset_id"]}'
        url=base+'/compare?selectedSessions='+status['project_id']
        async def read_trace(root_id):
            response=await client.traces.list_runs(str(root_id),project_id=status['project_id'],
                selects=['ID','INPUTS','OUTPUTS','ERROR','EXTRA','METADATA','START_TIME','END_TIME',
                         'PARENT_RUN_IDS','DOTTED_ORDER','FEEDBACK_STATS'])
            return [node.model_dump(mode='json') for node in (response.items or [])]
        links=[];status.update(status='verifying',verified=False,cases_verified=0)
        for original in bundle['runs']:
            run=remap_run(original,status['project_id'])
            # SmithDB indexing can lag successful writes. Bounded read retries do not alter scores.
            for attempt in range(4):
                try:
                    verify_readback(run,asyncio.run(read_trace(run['trace_id'])))
                    break
                except ValueError:
                    if attempt==3:raise
                    time.sleep(2**attempt)
            links.append({'case_id':run['case_id'],'run_id':run['trace_id'],
                          'local_trace_id':original['trace_id'],
                          'url':url+'&peek='+run['trace_id']+'&peeked_trace='+run['trace_id']+
                                '&start_time='+quote(run['spans'][0]['start_time'],safe='')+
                                '&peek_project='+status['project_id']})
            status['cases_verified']+=1
            if status['cases_verified']%10==0:
                save_report(status,folder/'langsmith-status.json')
                print('LangSmith readback: '+str(status['cases_verified'])+'/'+str(len(bundle['runs'])),flush=True)
        status.update(status='verified',verified=True,cases=links,dataset_url=base,experiment_url=url,
                      spans_verified=sum(len(r['spans']) for r in bundle['runs']),
                      verification_api='traces.list_runs + FEEDBACK_STATS',verified_at=datetime.now(timezone.utc).isoformat())
        status.pop('error_type',None)
        save_report(status,folder/'langsmith-status.json')
        return status
    except Exception as error:
        status.update(status='incomplete',verified=False,error_type=type(error).__name__)
        save_report(status,folder/'langsmith-status.json')
        raise ValueError('LangSmith readback is incomplete. Retry the verify command; it does not reupload or rerun Gemini.') from None
    finally:
        if owned:client.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare','upload','verify'))
    parser.add_argument('stage')
    parser.add_argument('--output-dir',type=Path,default=RESULTS)
    args=parser.parse_args()
    if not args.stage or Path(args.stage).name!=args.stage:
        parser.error('Use a simple stage name')
    try:
        action={'prepare':prepare,'upload':upload,'verify':verify_uploaded}[args.action]
        result=action(args.output_dir/args.stage)
        print('Local bundle prepared; nothing uploaded.' if args.action=='prepare' else
              'LangSmith verified '+str(result['cases_verified'])+' cases.')
    except (ValueError,OSError) as error:
        parser.error(str(error))


if __name__=='__main__':main()
