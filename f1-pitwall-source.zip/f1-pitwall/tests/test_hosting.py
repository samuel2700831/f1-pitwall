"""Hosting contracts: TLS, SQL compatibility and an idle/durable race clock."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch
from pitwall.agents import ResponsesClient
from pitwall.data import ROOT, load_timeline
from pitwall.service import PitwallService
from pitwall.storage import Connection, Postgres, Row, parameters


class StorageContracts(unittest.TestCase):
    def test_placeholders_leave_quoted_sql_and_values_untouched(self):
        self.assertEqual(parameters("SELECT '?' AS literal, \"?\" FROM t WHERE a=? AND b='it''s ?'"),
                         "SELECT '?' AS literal, \"?\" FROM t WHERE a=%s AND b='it''s ?'")

    def test_rows_support_both_names_and_positional_aggregates(self):
        row=Row([('count',3),('name','Charles')])
        self.assertEqual(row[0],3);self.assertEqual(row['name'],'Charles')
        self.assertEqual(dict(row),{'count':3,'name':'Charles'})

    def test_tls_cannot_be_disabled(self):
        for url in ('postgresql://example/db?sslmode=disable','postgresql://example/db?sslmode=prefer','postgresql:///db'):
            with self.assertRaises(ValueError):Postgres(url)

    def test_write_fence_blocks_a_replaced_server_before_state_changes(self):
        raw=MagicMock();raw.execute.return_value.fetchone.return_value={'instance_token':'new-deployment'}
        db=Connection(raw,'old-deployment',ValueError)
        with self.assertRaises(RuntimeError):db.execute('UPDATE runs SET status=?',('ready',))
        self.assertFalse(any('UPDATE runs' in str(call) for call in raw.execute.call_args_list))

    def test_write_lock_is_acquired_once_for_the_entire_transaction(self):
        raw=MagicMock();raw.execute.return_value.fetchone.return_value={'instance_token':'same'}
        db=Connection(raw,'same',ValueError)
        db.execute('BEGIN IMMEDIATE');db.execute('UPDATE runs SET status=?',('ready',));db.execute('UPDATE runs SET version=?',(2,))
        self.assertEqual(sum('pg_advisory_xact_lock' in str(c) for c in raw.execute.call_args_list),1)
        self.assertIn(unittest.mock.call('UPDATE runs SET status=%s',('ready',)),raw.execute.call_args_list)

    def test_reads_use_one_repeatable_snapshot_without_a_write_lock(self):
        raw=MagicMock();db=Connection(raw,'same',ValueError)
        db.execute('BEGIN');db.execute('SELECT * FROM runs WHERE run_id=?',('r',))
        raw.execute.assert_any_call('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ')
        self.assertFalse(any('advisory' in str(c) for c in raw.execute.call_args_list))


class HostedClockContracts(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.service=PitwallService(Path(self.temp.name)/'clock.sqlite',load_timeline(ROOT/'data/austin-2025-demo.json'),client=ResponsesClient(api_key=''))
        self.addCleanup(self.temp.cleanup);self.addCleanup(self.service.close)

    def test_idle_ticker_does_not_query_the_database(self):
        with patch.object(self.service._stop,'wait',side_effect=[False,True]),patch.object(self.service.replay,'_connect',side_effect=AssertionError('Idle database polling')):
            self.service._ticker()

    def test_older_get_cannot_revive_a_paused_clock(self):
        run=self.service.create('driver',1,'initial')
        running=self.service.playback('driver',run['run_id'],'start',80,'start',0)
        paused=self.service.playback('driver',run['run_id'],'pause',80,'pause',running['version'])
        self.service._schedule('driver',run['run_id'],running['version'],running['branch'])
        self.assertIsNone(self.service._scheduled[run['run_id']]['next_at'])
        self.assertEqual(self.service.get('driver',run['run_id'])['version'],paused['version'])

    def test_database_failure_recovers_by_saving_a_pause_not_advancing(self):
        run=self.service.create('driver',1,'initial');rid=run['run_id']
        self.service._schedule('driver',rid,0,{'playback':{'status':'running','next_at':0}})
        with patch.object(self.service._stop,'wait',side_effect=[False,True]),patch.object(self.service,'tick',side_effect=OSError('offline')):
            self.service._ticker()
        self.assertTrue(self.service._scheduled[rid]['fault'])
        self.service._scheduled[rid]['next_at']=0
        with patch.object(self.service._stop,'wait',side_effect=[False,True]),patch.object(self.service,'tick',side_effect=AssertionError('Must not advance')),patch.object(self.service,'_pause_clock') as pause:
            self.service._ticker();pause.assert_called_once_with('driver',rid)

    def test_restart_requires_explicit_resume_and_preserves_memory(self):
        run=self.service.create('driver',1,'initial');rid=run['run_id']
        remembered=self.service.remember('driver',rid,'Preserve my strategy','note',0)
        self.service.playback('driver',rid,'start',80,'start',remembered['version'])
        replacement=PitwallService(self.service.replay.database,self.service.replay.timeline,client=ResponsesClient(api_key=''))
        try:
            restored=replacement.get('driver',rid)
            self.assertEqual(restored['branch']['playback']['status'],'interrupted')
            self.assertTrue(any(m['content']=='Preserve my strategy' for m in restored['memory']))
            self.assertIsNone(replacement._scheduled[rid]['next_at'])
        finally:replacement.close()


if __name__=='__main__':unittest.main()
