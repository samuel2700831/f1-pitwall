"""Live-route configuration contracts with synthetic clients, never live keys."""
import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from pitwall.agents import ModelError
from pitwall.evals import PacedClient,read_dataset,label_approval,sha,run
from pitwall.langsmith_config import save_key,load_key
from pitwall.observability import Recorder,span,record_event
from pitwall.langsmith_export import remap_run,verify_readback


class LiveSetupTests(unittest.TestCase):
    def test_approval_requires_the_exact_dataset_and_all_cases(self):
        data=read_dataset()
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'approval.json'
            self.assertIsNone(label_approval(data,path))
            record={'status':'approved','dataset_sha256':sha(data),'case_ids':[c['id'] for c in data['cases']]}
            path.write_text(json.dumps(record))
            self.assertEqual(label_approval(data,path),record)
            record['case_ids'].pop();path.write_text(json.dumps(record))
            with self.assertRaises(ValueError):label_approval(data,path)

    def test_local_langsmith_key_permissions_and_provider_isolation(self):
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{'LANGSMITH_API_KEY':''}):
            path=Path(folder)/'key.json';key='lsv2_pt_synthetic_key_for_unit_tests_only'
            save_key(key,path);self.assertEqual(load_key(path),key)
            self.assertEqual(path.stat().st_mode&0o777,0o600)
            path.chmod(0o644);self.assertEqual(load_key(path),'')
            for wrong in ('sk-synthetic-openai-key-for-test','AIza-synthetic-google-key-for-test'):
                with self.assertRaises(ValueError):save_key(wrong,path)

    def test_pacing_is_not_counted_as_an_llm_request_span(self):
        class Client:
            provider='gemini';model='unit-test-model';configured=True
        client=PacedClient(Client(),12);recorder=Recorder()
        with patch('pitwall.evals.time.monotonic',side_effect=[100,104,112]),patch('pitwall.evals.time.sleep') as sleep:
            with recorder.activate():
                client.before_request();client.before_request()
            sleep.assert_called_once_with(8)
        self.assertEqual(len(recorder.spans),1)
        self.assertEqual(recorder.spans[0]['name'],'model.request_wait')
        self.assertEqual(recorder.spans[0]['run_type'],'chain')

    def test_cloud_export_isolates_ids_and_verifies_modern_readback(self):
        import uuid
        recorder=Recorder()
        with recorder.activate():
            with span('case',inputs={'lap':20}) as root:
                with span('model.generate','llm',inputs={'public':'input'}) as child:
                    child['outputs']={'choice':'hold'}
                    child['usage']={'input_tokens':10,'output_tokens':2,'total_tokens':12,'provider_reported':True}
                    record_event({'tool':'provider','status':'retry'})
                root['outputs']={'needs_human':True}
        original={'trace_id':root['id'],'spans':recorder.spans,'events':recorder.events,
                  'checks':[{'metric':'original_handoff_accuracy','passed':False}]}
        saved=copy.deepcopy(original)
        run=remap_run(original,uuid.uuid4())
        self.assertEqual(original,saved)
        self.assertNotEqual(run['trace_id'],original['trace_id'])
        self.assertEqual(run['spans'][1]['parent_id'],run['trace_id'])
        self.assertEqual(run['events'][0]['parent_id'],run['spans'][1]['id'])
        remote=[]
        for row in run['spans']:
            data=copy.deepcopy(row)
            data.update(inputs=row['inputs'] if isinstance(row['inputs'],dict) else {'value':row['inputs']},
                        outputs=row['outputs'] if isinstance(row['outputs'],dict) else {'value':row['outputs']},
                        extra={'metadata':{**row['metadata'],'local_latency_ms':row['latency_ms'],'usage_metadata':{k:v for k,v in (row['usage'] or {}).items() if k!='provider_reported'}}},
                        feedback_stats={'original_handoff_accuracy':{'avg':0,'n':1}},
                        dotted_order=('stamp'+run['trace_id']+'.' if row['parent_id'] else '')+'stamp'+row['id'])
            remote.append(data)
        verify_readback(run,remote)
        for field,value in [('outputs',{'choice':'pit_now'}),('dotted_order','wrong-parent'),
                            ('end_time','2020-01-01T00:00:00+00:00'),('extra',{})]:
            bad=copy.deepcopy(remote);bad[1][field]=value
            with self.assertRaises(ValueError):verify_readback(run,bad)
        bad=copy.deepcopy(remote);bad[0]['feedback_stats']['original_handoff_accuracy']['avg']=1
        with self.assertRaises(ValueError):verify_readback(run,bad)

    def test_resume_runs_only_unexecuted_cases_and_keeps_provider_failure(self):
        class Client:
            provider='gemini';model='unit-test-resume-fixture';configured=True
            def __init__(self,fail=False):self.fail=fail
            def create(self,payload,log):
                if self.fail:raise ModelError('Synthetic provider unavailable')
                if not any(item.get('type')=='function_call_output' for item in payload['input']):
                    tools=[('recall_memory',{}),('delegate_rival_analyst',{}),('delegate_conditions_agent',{}),
                           ('delegate_leclerc_agent',{}),('compare_strategies',{'stress':'baseline'})]
                else:tools=[('propose_decision',{'choice':'hold','rationale':'Synthetic fixture stays out.','needs_human':True})]
                return {'output':[{'type':'function_call','call_id':str(i),'name':name,'arguments':json.dumps(args)}
                                  for i,(name,args) in enumerate(tools)]}
        with tempfile.TemporaryDirectory() as folder,patch('urllib.request.urlopen',side_effect=AssertionError('Network forbidden')),patch('builtins.print'):
            with patch('pitwall.gemini.GeminiClient',return_value=Client(True)):
                first=run('resume-contract',mode='gemini',output_dir=folder,interval=0,request_interval=0)
            self.assertFalse(first['complete']);self.assertEqual(len(first['results']),1)
            failed=copy.deepcopy(first['results'][0]);self.assertEqual(failed['verdict'],'fail')
            with patch('pitwall.gemini.GeminiClient',return_value=Client()):
                done=run('resume-contract',mode='gemini',output_dir=folder,interval=0,request_interval=0,resume=True)
            self.assertTrue(done['complete']);self.assertEqual(len(done['results']),40)
            self.assertEqual(done['results'][0],failed)
            self.assertEqual(done['resume_history'][0]['preserved_executed_cases'],1)
            self.assertEqual(len({r['case_id'] for r in done['results']}),40)


if __name__=='__main__':unittest.main()
