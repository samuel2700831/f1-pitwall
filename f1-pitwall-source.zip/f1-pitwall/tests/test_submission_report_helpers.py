"""Protect paired-input identity and the cost/latency populations."""
import copy
import unittest
from evals.build_submission import normalized_inputs,performance

class PairReportTests(unittest.TestCase):
    def test_only_telemetry_bookkeeping_is_normalized(self):
        row={'observed':{'as_of':'2025-01-01','called_at':'evidence-time','drivers':[{'timing_at':'2025-01-01'}]},
             'car':{'compound':'SOFT','telemetry':{'snapshot_id':'runtime-id','reports':[{'read_at':'now','pace':90}],
                                               'trace':[{'called_at':'now','tool':'weather'}]},
                    'telemetry_history':[{'read_at':'now','information':{'available_at':'2025-01-01'}}]}}
        original=copy.deepcopy(row);other=copy.deepcopy(row)
        other['car']['telemetry']['snapshot_id']='different';other['car']['telemetry']['reports'][0]['read_at']='later'
        self.assertEqual(normalized_inputs(row),normalized_inputs(other));self.assertEqual(row,original)
        for path,value in [(('observed','as_of'),'future'),(('observed','called_at'),'different-evidence'),(('car','compound'),'HARD')]:
            bad=copy.deepcopy(other);bad[path[0]][path[1]]=value
            self.assertNotEqual(normalized_inputs(row),normalized_inputs(bad))

    def test_performance_excludes_fixtures_and_preserves_missing_usage(self):
        rows=[{'live_model_case':True,'provider_fixture':False,'latency_ms':v*1000,'usage':{'total_tokens':v*10}}
              for v in (1,2,3,4)]
        rows.append({'live_model_case':False,'provider_fixture':True,'latency_ms':1000000,'usage':{'total_tokens':99999}})
        result=performance({'results':rows})
        self.assertEqual(result['workflow_p95_seconds'],4)
        self.assertEqual(result['mean_total_tokens'],25)
        self.assertEqual(result['live_cases'],4);self.assertEqual(result['fixture_cases'],1)
        rows[0]['usage']=None
        self.assertIsNone(performance({'results':rows})['mean_total_tokens'])

if __name__=='__main__':unittest.main()
