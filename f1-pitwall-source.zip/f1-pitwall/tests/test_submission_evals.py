"""Regressions for live-eval improvements, without contacting a provider."""
import copy
import unittest
from pitwall.evals import concept_present
from tests import test_phase2_evals as fixtures

class ConceptRubricTests(unittest.TestCase):
    def test_domain_synonyms_and_boundaries(self):
        for phrase in ('dry tyres','dry tires','slicks'):
            self.assertTrue(concept_present(phrase,'slick'))
        self.assertTrue(concept_present('compound is unconfirmed','unknown'))
        self.assertTrue(concept_present('soft tyres are old','tyre'))
        self.assertTrue(concept_present('rivals have stopped','rival'))
        self.assertTrue(concept_present('change to intermediates','intermediate'))
        self.assertTrue(concept_present('SC reduces transit','sc'))
        self.assertFalse(concept_present('disclose evidence','sc'))
        self.assertFalse(concept_present('VSC reduces transit','sc'))
        self.assertFalse(concept_present('known compound','unknown'))
        self.assertFalse(concept_present('rain is falling','slick'))

class DecisionConstraintTests(unittest.TestCase):
    setUpClass=classmethod(fixtures.Phase2Evaluators.setUpClass.__func__)
    tearDownClass=classmethod(fixtures.Phase2Evaluators.tearDownClass.__func__)
    case=fixtures.Phase2Evaluators.case
    def test_comparison_exposes_actual_damage_flags_and_evidence_gaps(self):
        from pitwall.evals import prepare_case
        from pitwall.agents import StrategyWorkflow
        for ident in ('puncture-sc','partial-rivals','missing-rivals','fresh-medium'):
            case=self.case(ident)
            observed,car,memory=prepare_case(self.snapshot,case,self.dataset['defaults'])
            original=copy.deepcopy((observed,car,memory))
            workflow=StrategyWorkflow(observed,car,memory,client=self.client)
            result=workflow.call('compare_strategies',{'stress':'baseline'})
            constraints=result['decision_constraints']
            self.assertEqual(constraints['race_control'],observed['race_control'])
            self.assertEqual(constraints['tyre_compound'],car['compound'])
            if ident=='puncture-sc':
                self.assertIn('puncture',constraints['active_damage'])
                self.assertTrue(constraints['pit_transit_reduced'])
            if 'rivals' in ident:
                self.assertTrue(constraints['evidence_gaps'])
                self.assertTrue(result['approval_requirements']['hold']['needs_human'])
            self.assertEqual((observed,car,memory),original)
