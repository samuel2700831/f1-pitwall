"""Publication must fail closed and must not echo scanner matched text."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('check_secrets', Path(__file__).parents[1] / 'scripts/check_secrets.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SecretScanTests(unittest.TestCase):
    def run_scan(self, exit_code, findings):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            def fake_run(args, **kwargs):
                report = Path(args[args.index('--report-path') + 1])
                report.write_text(json.dumps(findings))
                self.assertIn('--redact=100', args)
                self.assertIn('--ignore-gitleaks-allow', args)
                self.assertEqual(Path(args[args.index('--gitleaks-ignore-path') + 1]).read_text(), '')
                self.assertIn('--log-opts=--all --full-history', args)
                return subprocess.CompletedProcess(args, exit_code, 'private match text', '')
            with patch.object(module.subprocess, 'run', side_effect=fake_run):
                return module.scan('gitleaks', 'git', path, path)

    def test_clean_scan(self):
        self.assertTrue(self.run_scan(0, [])['passed'])

    def test_finding_is_blocked_and_value_omitted(self):
        result = self.run_scan(1, [{'File': 'sample', 'RuleID': 'example', 'Secret': 'private match text', 'Match': 'private match text'}])
        self.assertFalse(result['passed'])
        self.assertNotIn('private match text', json.dumps(result))

    def test_inconsistent_success_with_findings_is_blocked(self):
        self.assertFalse(self.run_scan(0, [{'File': 'sample'}])['passed'])

    def test_scanner_error_is_not_a_clean_scan(self):
        with self.assertRaises(RuntimeError):
            self.run_scan(2, [])


if __name__ == '__main__':
    unittest.main()
