"""Test the evaluators with deliberately wrong answers, not just happy outputs."""
import copy
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pitwall.agents import ResponsesClient, StrategyWorkflow
from pitwall.data import ROOT, load_timeline
from pitwall.evals import (read_dataset, prepare_case, run_case, score_case, REQUIRED,
                           compare_reports, run, aggregate, regrade)
from pitwall.gemini import GeminiClient
from pitwall.langsmith_export import prepare, validate_trace, build_tree, upload
from pitwall.observability import Recorder, public, span
from pitwall.service import PitwallService
from pitwall.specialists import Specialist


class Phase2Evaluators(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.client=ResponsesClient(api_key='')
        cls.service=PitwallService(Path(cls.tmp.name)/'tests.sqlite',
            load_timeline(ROOT/'data/austin-2025-demo.json'),client=cls.client)
        cls.snapshot=cls.service.create('test-owner',15,'checkpoint')
        cls.dataset=read_dataset()

    @classmethod
    def tearDownClass(cls):
        cls.service.close();cls.tmp.cleanup()

    def case(self, name):
        return next(copy.deepcopy(c) for c in self.dataset['cases'] if c['id']==name)

    def result(self, name='puncture-green'):
        return run_case(self.snapshot,self.case(name),self.dataset['defaults'],self.client,'local')

    def rescore(self, row, *, live=False):
        workflow=SimpleNamespace(used=set(REQUIRED),trace=[{'tool':'recall_memory',
                                                          'information':row['inputs']['memory']}])
        return score_case(self.case(row['case_id']),row['inputs'],row['decision'],workflow,
                          SimpleNamespace(spans=row['spans']),True,live=live)

    def passed(self, checks, metric):
        return next(c['passed'] for c in checks if c['metric']==metric)

    def test_dataset_is_versioned_labeled_and_has_separate_splits(self):
        self.assertEqual(len(self.dataset['cases']),40)
        self.assertEqual(sum(c['split']=='holdout' for c in self.dataset['cases']),10)
        self.assertEqual({c['category'] for c in self.dataset['cases']},
                         {'happy','wear','damage','weather','flags','memory','evidence','recovery'})
        self.assertTrue(all(c['label_status']=='author_labeled_pending_human_review' for c in self.dataset['cases']))

    def test_preparation_does_not_edit_user_checkpoint(self):
        original=copy.deepcopy(self.snapshot)
        prepare_case(self.snapshot,self.case('combined-damage'),self.dataset['defaults'])
        self.assertEqual(self.snapshot,original)

    def test_bad_original_puncture_call_fails_even_if_guard_fixes_final(self):
        row=self.result()
        row['decision']['source']='gemini'
        row['decision']['model_proposal']={'choice':'hold','needs_human':False,'rationale':'Stay out despite the puncture.'}
        checks=self.rescore(row,live=True)
        self.assertTrue(self.passed(checks,'decision_accuracy'))
        self.assertFalse(self.passed(checks,'original_decision_accuracy'))
        self.assertFalse(self.passed(checks,'original_handoff_accuracy'))

    def test_invented_rejoin_number_fails_numeric_grounding(self):
        row=self.result()
        row['decision']['rationale']='Box for the puncture. Estimated rejoin P99.'
        self.assertFalse(self.passed(self.rescore(row),'numeric_grounding'))

    def test_guaranteed_pass_assertion_fails(self):
        row=self.result();row['decision']['rationale']='Box for the puncture. You will definitely overtake the leader.'
        self.assertFalse(self.passed(self.rescore(row),'no_guaranteed_pass'))

    def test_missing_incident_context_fails_even_when_choice_is_right(self):
        row=self.result();row['decision']['rationale']='Box now because it is best.'
        self.assertTrue(self.passed(self.rescore(row),'decision_accuracy'))
        self.assertFalse(self.passed(self.rescore(row),'explanation_coverage'))

    def test_future_input_is_detected(self):
        row=self.result();row['inputs']['observed']['rivals']['drivers'][0]['timing_at']='2099-01-01T00:00:00Z'
        self.assertFalse(self.passed(self.rescore(row),'no_future_data'))

    def test_fabricated_specialist_output_is_detected_even_when_choice_is_right(self):
        row=self.result()
        rivals=next(r for r in row['decision']['specialists'] if r['role']=='Rival Analyst')
        rivals['tools']['read_rival_positions']['drivers'][0]['timing_at']='2099-01-01T00:00:00Z'
        checks=self.rescore(row)
        self.assertTrue(self.passed(checks,'decision_accuracy'))
        self.assertFalse(self.passed(checks,'specialist_accuracy'))
        self.assertFalse(self.passed(checks,'no_future_data'))

    def test_wrong_pit_service_cost_fails_against_literal_label(self):
        row=self.result();row['decision']['position_context']['stop_cost']['total_loss_seconds']=1
        self.assertFalse(self.passed(self.rescore(row),'pit_cost_accuracy'))

    def test_missing_memory_content_fails(self):
        row=self.result('remember-track-position')
        workflow=SimpleNamespace(used=set(REQUIRED),trace=[{'tool':'recall_memory','information':[]}])
        checks=score_case(self.case(row['case_id']),row['inputs'],row['decision'],workflow,
                          SimpleNamespace(spans=row['spans']),True)
        self.assertFalse(self.passed(checks,'memory_recall'))

    def test_state_mutation_is_a_hard_failure(self):
        row=self.result();workflow=SimpleNamespace(used=set(REQUIRED),trace=[])
        checks=score_case(self.case(row['case_id']),row['inputs'],row['decision'],workflow,
                          SimpleNamespace(spans=row['spans']),False)
        self.assertFalse(self.passed(checks,'execution_safety'))

    def test_missing_evidence_delegation_is_detected(self):
        row=self.result();workflow=SimpleNamespace(used={'propose_decision'},trace=[])
        checks=score_case(self.case(row['case_id']),row['inputs'],row['decision'],workflow,
                          SimpleNamespace(spans=row['spans']),True)
        self.assertFalse(self.passed(checks,'evidence_tool_coverage'))

    def test_transient_read_retries_once_and_has_real_failed_child_span(self):
        row=self.result('tool-transient')
        reads=[s for s in row['spans'] if s['name']=='read_weather']
        self.assertEqual(len(reads),2)
        self.assertEqual(reads[0]['error'],'TimeoutError');self.assertIsNone(reads[1]['error'])
        self.assertEqual(row['verdict'],'pass')
        validate_trace(row['spans'],row['trace_id'])

    def test_persistent_read_is_unavailable_not_an_infinite_retry(self):
        row=self.result('tool-persistent')
        self.assertEqual(sum(s['name']=='read_weather' and s['error'] is not None for s in row['spans']),2)
        self.assertTrue(row['decision']['needs_human'])
        self.assertIn('unavailable',row['decision']['rationale'])
        self.assertEqual(row['verdict'],'pass')

    def test_scope_or_programming_errors_are_not_retried_or_hidden(self):
        o,b,m=prepare_case(self.snapshot,self.case('fresh-medium'),self.dataset['defaults'])
        with patch.object(Specialist,'tool',side_effect=ValueError('Programming error')) as tool:
            with self.assertRaises(ValueError):Specialist('Rival Analyst',o,b,lambda *a:None).run()
            self.assertEqual(tool.call_count,1)

    def test_all_specialist_reads_unavailable_still_produce_bounded_handoff(self):
        o,b,m=prepare_case(self.snapshot,self.case('unknown-tyres'),self.dataset['defaults'])
        o.update(condition='unknown',weather_age_seconds=None,race_control='UNKNOWN')
        o['rivals'].update(available=False,drivers=[],nearby=[])
        original=copy.deepcopy(b)
        with patch.object(Specialist,'tool',side_effect=TimeoutError('Synthetic outage')) as tool:
            decision=StrategyWorkflow(o,b,m,client=self.client).run('local')
        self.assertEqual(tool.call_count,22)
        self.assertTrue(decision['needs_human'])
        self.assertEqual(decision['recommended'],'hold')
        self.assertLessEqual(len(decision['rationale']),1200)
        self.assertEqual(b,original)

    def test_fixture_llm_is_labeled_and_not_scored_as_real_gemini(self):
        row=self.result('model-invalid-schema')
        self.assertFalse(row['live_model_case']);self.assertTrue(row['provider_fixture'])
        self.assertIsNone(row['usage'])
        self.assertEqual(row['usage_status'],'not_applicable_fixture')
        self.assertTrue(all(s['metadata']['provider']=='scripted_fixture' for s in row['spans'] if s['run_type']=='llm'))

    def test_nested_span_isolation_and_error_redaction(self):
        recorder=Recorder()
        with recorder.activate(),span('root'):
            with self.assertRaises(RuntimeError):
                with span('child','tool'):
                    raise RuntimeError('secret-api-key-must-not-appear')
        validate_trace(recorder.spans,recorder.spans[0]['id'])
        self.assertNotIn('secret-api-key',json.dumps(recorder.spans))
        self.assertEqual(recorder.spans[1]['parent_id'],recorder.spans[0]['id'])
        other=Recorder()
        with other.activate(),span('other'):pass
        self.assertIsNone(other.spans[0]['parent_id'])

    def test_credentials_and_native_reasoning_are_omitted(self):
        data=public({'api_key':'private-key','headers':{'Authorization':'Bearer private'},
                     'parts':[{'type':'gemini_content','content':'private-reasoning'},
                              {'thought':True,'text':'hidden-thought'},
                              {'thoughtSignature':'opaque-signature'}]})
        serialized=json.dumps(data)
        for value in ('private-key','Bearer private','private-reasoning','hidden-thought','opaque-signature'):
            self.assertNotIn(value,serialized)

    def test_gemini_token_metadata_is_provider_reported_not_estimated(self):
        response={'candidates':[{'finishReason':'STOP','content':{'role':'model','parts':[
            {'functionCall':{'name':'recall_memory','args':{}}}]}}],
            'usageMetadata':{'promptTokenCount':10,'toolUsePromptTokenCount':2,
                             'candidatesTokenCount':5,'thoughtsTokenCount':3,'totalTokenCount':20}}
        payload={'model':'test','instructions':'test','input':[], 'tools':[]}
        result=GeminiClient(api_key='',transport=lambda body:response).create(payload,lambda *a:None)
        self.assertEqual([result['usage'][k] for k in ('input_tokens','output_tokens','total_tokens')],[12,8,20])
        response.pop('usageMetadata')
        self.assertIsNone(GeminiClient(api_key='',transport=lambda body:response).create(payload,lambda *a:None)['usage'])

    def test_comparisons_refuse_changed_labels_or_partial_population(self):
        report={'schema_version':'1','dataset_sha256':'a','mode':'local','race_data_sha256':'b',
                'rivals_sha256':'c','complete':True,'stage':'a','results':[], 'summary':{'metrics':{}}}
        other=copy.deepcopy(report);other['dataset_sha256']='changed'
        with self.assertRaises(ValueError):compare_reports(report,other)
        other=copy.deepcopy(report);other['complete']=False
        with self.assertRaises(ValueError):compare_reports(report,other)

    def test_case_failure_cost_does_not_double_count_multiple_metric_failures(self):
        row=self.result();row['checks'][0]['passed']=False;row['checks'][1]['passed']=False;row['verdict']='fail'
        total=aggregate([row],self.dataset['cases'])
        self.assertEqual(total['unique_failed_case_review_seconds'],self.case('puncture-green')['failure_review_seconds_assumption'])

    def test_local_full_run_and_bundle_never_call_a_provider_or_langsmith(self):
        with tempfile.TemporaryDirectory() as folder, \
             patch('urllib.request.urlopen',side_effect=AssertionError('Network forbidden')):
            with patch('builtins.print'):
                report=run('offline-test',output_dir=folder)
            self.assertEqual(report['summary']['passed'],40)
            self.assertEqual(report['summary']['live_model_cases'],0)
            bundle=prepare(Path(folder)/'offline-test')
            self.assertEqual(bundle['upload_status'],'not_uploaded')
            self.assertEqual(len(bundle['examples']),40)
            self.assertEqual(len(bundle['runs']),40)
            self.assertEqual(sum(s['run_type']=='llm' for r in bundle['runs'] for s in r['spans']),4)
            original=(Path(folder)/'offline-test/report.json').read_bytes()
            regraded=regrade('offline-test','regraded',output_dir=folder)
            self.assertEqual((Path(folder)/'offline-test/report.json').read_bytes(),original)
            self.assertEqual(regraded['summary']['passed'],40)
            self.assertEqual(regraded['grading_revision']['inference_stage'],'offline-test')
            delta=compare_reports(report,regraded)
            self.assertTrue(all(m['delta_percentage_points']==0 for m in delta['metrics'].values()))
            with patch('pitwall.langsmith_export.load_key',return_value=''):
                with self.assertRaisesRegex(ValueError,'Set LANGSMITH_API_KEY privately'):
                    upload(Path(folder)/'offline-test')
            with self.assertRaises(ValueError):run('offline-test',output_dir=folder)


if __name__=='__main__':unittest.main()
