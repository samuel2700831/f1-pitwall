"""Build the review artifacts from preserved results; does not run a model."""
import csv
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pitwall.evals import read_dataset,compare_reports,save_report,label_approval

STAGES=['scored-baseline','scored-improvement-1','scored-improvement-2',
        'scored-improvement-3','scored-improvement-4','final-local']
LABELS=['Baseline','1. Explain observed context','2. Evidence-quality handoff',
        '3. Withhold unsupported ranks','4. Bounded specialist recovery','Final source verification']


def main():
    reports=[json.loads((ROOT/'.local/evals'/name/'report.json').read_text()) for name in STAGES]
    golden=read_dataset()
    approval_record=label_approval(golden)
    review_status=('approved '+approval_record['approved_on']) if approval_record else 'pending human review'
    validation=json.loads((ROOT/'.local/validation/predeploy-summary.json').read_text())
    sdk=json.loads((ROOT/'evals/reports/sdk-verification.json').read_text())
    changes=[compare_reports(a,b) for a,b in zip(reports,reports[1:])]
    total=compare_reports(reports[0],reports[-1])
    summary={'dataset_id':golden['dataset_id'],'label_review':review_status,
             'metric_version':reports[-1]['schema_version'],'mode':'local',
             'live_model_requests':0,'langsmith_uploads':0,
             'stages':[{'label':label,'stage':r['stage'],'summary':r['summary'],'splits':r['splits'],
                        'report':'../../.local/evals/'+r['stage']+'/report.json'} for label,r in zip(LABELS,reports)],
             'adjacent_deltas':changes,'baseline_to_final':total,'regression_verification':validation,
             'langsmith_sdk_verification':sdk,
             'scope':'Local behavioral contracts only. No semantic judge, calibrated physics, real Gemini quality or cloud-ingestion claim.'}
    save_report(summary,ROOT/'evals/reports/summary.json')
    case_folder=ROOT/'evals/reports/cases';case_folder.mkdir(parents=True,exist_ok=True)
    case_lookups=[{row['case_id']:row for row in report['results']} for report in reports]
    for case in golden['cases']:
        evidence={'case':case,'metric_version':reports[-1]['schema_version'],
                  'stages':[{'stage':stage,'label':label,'verdict':lookup[case['id']]['verdict'],
                             'checks':lookup[case['id']]['checks'],
                             'rationale':(lookup[case['id']]['decision'] or {}).get('rationale'),
                             'trace':'../../../.local/evals/'+stage+'/traces/'+case['id']+'.json'}
                            for stage,label,lookup in zip(STAGES,LABELS,case_lookups)]}
        save_report(evidence,case_folder/(case['id']+'.json'))
    with (ROOT/'evals/reports/case-review.csv').open('w',newline='') as file:
        fields=['case_id','category','split','lap','allowed_choices','needs_human','rationale_concepts',
                'label_reason','human_review_status',*STAGES,'baseline_failure_modes','final_trace']
        writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
        by_stage=[{row['case_id']:row for row in r['results']} for r in reports]
        for case in golden['cases']:
            row={'case_id':case['id'],'category':case['category'],'split':case['split'],'lap':case['lap'],
                 'allowed_choices':' | '.join(case['allowed_choices']),'needs_human':case['needs_human'],
                 'rationale_concepts':json.dumps(case['rationale_concepts']),'label_reason':case['label_reason'],
                 'human_review_status':review_status,
                 'baseline_failure_modes':' | '.join(sorted({c['failure_mode'] for c in by_stage[0][case['id']]['checks'] if not c['passed']})),
                 'final_trace':'../../.local/evals/final-local/traces/'+case['id']+'.json'}
            row.update({stage:lookup[case['id']]['verdict'] for stage,lookup in zip(STAGES,by_stage)})
            writer.writerow(row)
    lines=['# F1 Pitwall — Phase 2 evaluation results','',
           '**Historical local experiment results.** Current label review: '+review_status+'. The counts below concern local runs only. See [the subsequent live Gemini and LangSmith report](LIVE-REPORT.md) for current model results.','',
           'The final code passes all 40 golden cases. The preserved baseline passed 20. Four targeted changes improved explanation context, evidence-quality handoff, incomplete-field projections and bounded specialist recovery. These scores measure the listed contracts, not general intelligence or optimal racing strategy.','',
           '## Measured iterations','',
           '| Stage | All cases | Development | Holdout | Change in case pass rate |',
           '| --- | --- | --- | --- | --- |']
    last=None
    for label,r in zip(LABELS,reports):
        count=r['summary']['passed'];delta='—' if last is None else f'{(count-last)/40*100:+.1f} pp'
        lines.append(f'| {label} | {count}/40 | {r["splits"]["development"]["passed"]}/30 | {r["splits"]["holdout"]["passed"]}/10 | {delta} |')
        last=count
    lines.extend(['','Each inference run has its own source/prompt/data fingerprints. The five `scored-*` stages apply the same metric version 1.1 to preserved inference outputs, without changing the original traces. `final-local` is a new execution of the final source. The holdout split was fixed before the baseline but was not independently blinded.','',
                  '## Metric deltas','',
                  '| Metric | Baseline | Final | Delta |',
                  '| --- | --- | --- | --- |'])
    for name,metric in total['metrics'].items():
        a,b=metric['before'],metric['after']
        lines.append(f'| {name} | {a["passed"]}/{a["applicable"]} ({a["rate"]*100:.2f}%) | {b["passed"]}/{b["applicable"]} ({b["rate"]*100:.2f}%) | {metric["delta_percentage_points"]:+.2f} pp |')
    lines.extend(['','The primary goal is safe, evidence-backed advice: final-action accuracy ≥95%, exact handoff behavior, all required evidence tools, no unauthorized state changes and no future-data use. Explanations target ≥90% labeled concept coverage. The final local run meets all configured gates. Live-model gates are reported separately in [LIVE-REPORT.md](LIVE-REPORT.md).','',
                  '## Baseline failures and cost assumptions','',
                  'The dominant mode was **explanation_omits_context**, affecting 18 cases. The recommendation often named the numerical winner without mentioning the puncture, wing, rain, caution flag or uncertainty that the human needed to understand. Five cases failed handoff expectations. Two specialist timeouts produced no decision, and one partial-field case exposed a confident rank. A case can appear in multiple clusters.','',
                  '| Failure mode | Cases | Severity points | Assumed review time |',
                  '| --- | --- | --- | --- |'])
    for cluster in reports[0]['summary']['failure_modes']:
        lines.append(f'| {cluster["mode"]} | {cluster["case_count"]} | {cluster["severity_points"]} | {cluster["estimated_review_seconds"]/60:.1f} min |')
    lines.extend(['',
           f'Unique failed-case review effort was **{reports[0]["summary"]["unique_failed_case_review_seconds"]/60:.1f} assumed minutes per 40-case batch**. This is a scenario-weighted estimate using the per-case seconds in the golden dataset, not an observed cost or a monetary saving. Cluster totals overlap. All current labeled cases pass after the changes, so this narrow modeled review total is zero; real-world failure cost remains unknown. There were no model API requests in these local runs.','',
           '## What changed and what remained','',
           '1. **Observed context in local advice.** Name actual tyres/age, track state, flags and specific damage. Cite immediate-stop rejoin estimates only for an immediate stop. This fixed many explanation omissions, but did not fix evidence-quality handoff.','2. **Evidence-quality gates.** Unknown race control/tyres, stale or missing weather, and unavailable/partial rivals now require review. Tool comparison outputs carry those approval requirements for the LLM. This fixed five handoff cases; it still left a misleading partial-field projection.','3. **Incomplete-field forecasts.** Keep pit-cost calculations, but withhold full-field pit-exit ranks, neighbor gaps and recovery positions when the 19-opponent timing field is incomplete. This fixed the remaining projection case; it did not recover failed tool reads.','4. **Bounded read recovery.** Retry recognized transient read errors once; persistent failures return explicit unavailable evidence and force human review. Scope/schema/programming errors remain visible. An additional all-tools-outage regression caught an overlong rationale; the compact explanation now stays within the schema while full failures remain in reports and reasons.','',
           'No model weights were trained, no numerical race coefficients were tuned, and no labels were changed to fit an answer. Local explanation improvements do not demonstrate that Gemini will follow the updated prompt. The next experiment must measure that separately.','',
           '## Trace evidence','',
           f'The final run contains **{sdk["spans"]} recorded spans across 40 case roots**. Parent/child relationships, inputs, outputs, timestamps and errors are retained. Four LLM-shaped calls belong to the two explicit malformed-provider fixtures; the 38 ordinary local cases make no LLM calls. Local token usage is null/not applicable. A separate synthetic usage test verified Gemini-to-LangSmith token-field mapping without contacting either service.','',
           'The optional LangSmith SDK accepted all final trace trees through an offline client with network socket connections blocked. This verifies local construction and serialization, **not cloud ingestion**. The subsequent cloud experiment is documented in [LIVE-REPORT.md](LIVE-REPORT.md). See [SDK check](reports/sdk-verification.json).','',
           '## Case-level review','',
           'Each final result links to its actual trace JSON. Expected labels are in [golden-v1.json](golden-v1.json); every metric retains expected/actual feedback in the detailed reports. A complete label/outcome sheet is available as [CSV](reports/case-review.csv).','',
           '| Case | Split | Baseline | Final | Trace |',
           '| --- | --- | --- | --- | --- |'])
    before={r['case_id']:r for r in reports[0]['results']}
    final={r['case_id']:r for r in reports[-1]['results']}
    for case in golden['cases']:
        key=case['id']
        lines.append(f'| [{key}](reports/cases/{key}.json) | {case["split"]} | {before[key]["verdict"]} | {final[key]["verdict"]} | [JSON](../.local/evals/final-local/traces/{key}.json) |')
    lines.extend(['','## Verification and remaining work','',
           f'- **{validation["unit_tests"]} unit tests passed**, including adversarial grader tests, retry bounds, trace privacy, token mapping, local-only execution and immutable regrading.',
           f'- **{validation["local"]["passed"]} existing backend scenario evaluations passed** at six checkpoints.',
           '- **40/40 final golden cases passed**; every applicable configured gate passed.',
           '- LangSmith SDK verification was offline only. No real provider token/latency/cost evaluation is claimed.',
           '- Label review: '+review_status+'; explanation checks cover selected concepts and rejoin numbers rather than full semantic correctness.',
           '- Next: compare a live candidate with the separately measured Gemini baseline, add repeated unseen cases and calibrate the explanation rubric.',
           '', 'Reproduce the final run with `python3 -m pitwall.evals run --stage new-local-run`. See [evaluation instructions](README.md) for metrics, gates, tracing, live-run controls and caveats.'])
    (ROOT/'evals/REPORT.md').write_text('\n'.join(lines)+'\n')
    print('Wrote REPORT.md, reports/summary.json and reports/case-review.csv')


if __name__=='__main__':main()
