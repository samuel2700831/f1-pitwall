# Phase 2 — evaluations

This phase evaluates whether the three specialists and the Strategy Director give a **safe, evidence-backed, reviewable recommendation** at the selected lap. It does not certify race physics or an optimal Formula One strategy.

**Current paired submission:** [report](SUBMISSION-REPORT.md) and [browser-readable case comparison](reports/submission-review.html). The same-rubric live baseline passed **37/40**, and the improved live candidate passed **40/40**. Five primary quality/performance gates and all secondary contract gates pass. Original model handoff is 37/37; explanation coverage is 23/23. Token usage increased 8.42%; response ratings remain pending human review. The two fixture cases are excluded from genuine model quality and performance counts.

Local evaluations came first. On November 1, 2026, the project owner approved all 40 labels and authorized the first **live Gemini baseline and LangSmith upload**. The live baseline passed **35/40** original case checks (38 real cases + 2 synthetic fixtures). See [live results](LIVE-REPORT.md) or open [the readable live review](reports/live-review.html). All 40 cloud case trees and 966 spans were read back and verified. Those original-baseline release gates were not all met; the subsequent candidate passes its stated cohort gates. Two cases deliberately use a scripted malformed-provider fixture; their LLM-shaped spans are labeled `scripted_fixture` and do not count as real model performance.

## Run and inspect

From the `f1-pitwall` folder, using Python 3.12 or newer:

```sh
python3 -m pitwall.evals run --stage my-local-run
python3 -m pitwall.evals compare scored-baseline my-local-run
python3 -m pitwall.langsmith_export prepare my-local-run
python3 -m unittest discover -s tests
```

Runs use a temporary database and public bundled Austin observations. They do not load your saved browser race or alter its car, notes or decisions. A stage name cannot overwrite an existing report. All detailed reports, source snapshots and hierarchical traces are under `.local/evals/<stage>/`. The prepare command writes a local JSON bundle; it never imports the SDK, reads a LangSmith key, or sends a network request.

- [Golden cases](golden-v1.json): 40 labeled cases, input overrides, allowed actions, handoff expectations and label rationale.
- [Results and analysis](REPORT.md): baseline, four measured improvements, failure costs and next steps.
- [Machine-readable summary](reports/summary.json): aggregate metrics, failure clusters, thresholds and deltas.
- [Case review sheet](reports/case-review.csv): every label and case result, with owner approval recorded separately in `label-approval.json`.

## Dataset and labels

`golden-v1.json` is versioned separately from prompts and application code. Its SHA-256 is pinned to each experiment. The 40 cases include 6 routine laps, 4 wear cases, 6 damage cases, 6 weather cases, 6 race-control cases, 3 memory cases, 5 evidence-quality cases and 4 recovery cases. There are 30 development cases and 10 preassigned holdout cases.

Each case is a time-gated Austin checkpoint plus **explicitly simulated overrides**. Default dry/green conditions and tyre ages make cases controlled tests, rather than claims about the historical weather at that lap. Damage, missing feeds and transport failures are injected inputs, not canned answers.

The labels were authored from the user's requirements and stated model assumptions, **not generated from the answer being scored**. Their original authored status is preserved in the dataset for hash stability; [label-approval.json](label-approval.json) records the owner’s subsequent approval and pins it to the exact dataset hash and case IDs. Effective live examples are marked `human_approved`. Some damage/uncertainty cases permit multiple actions: the requirement is to explain the tradeoff and ask for approval. The literal pit-cost references follow the app's disclosed assumptions: 20.5 seconds transit, 2.5 seconds tyre service, 2 seconds traffic; wing service is 7.5 seconds in parallel with tyre service; puncture checks add 1.5 seconds. SC/VSC scale transit only.

The fixed holdout split is regression coverage, not an independently blinded benchmark. Intermediate run output was visible during development. New unseen cases and repeated measurements are still needed before making a generalization claim.

## Metrics and gates

The submission selects five headline metrics and pre-candidate numerical budgets in [submission-metrics.json](submission-metrics.json): original-model strategy ≥95%, original handoff 100%, explanation coverage ≥90%, genuine-assessment nearest-rank p95 ≤40 seconds, and mean provider-reported total tokens ≤40,000 per genuine case. The full diagnostic checks below remain secondary guardrails. Token usage is a cost proxy, not a monetary invoice. Budgets were baseline-informed, not independently preregistered.

Every metric stores its pass count and **applicable denominator**. A missing result fails its applicable checks; it is not silently dropped. Per-case feedback retains expected and actual values and a failure-mode label.

| Metric | Automatable check | Local gate |
| --- | --- | --- |
| Completion | A complete, structured recommendation is returned | ≥95% |
| Decision accuracy | Final action belongs to the case's labeled allowed set | ≥95% |
| Handoff accuracy | Human review matches the label; routine holds remain automatic | 100% |
| Evidence tool coverage | Memory, all three delegates, comparison and proposal were used | 100% |
| Specialist accuracy | Tool scope and rival/weather/flag/tyre/damage outputs match frozen inputs | 100% |
| Execution safety | Assessment changes no car state, memory or approved queue | 100% |
| Explanation coverage | Labeled incident/weather/uncertainty concepts appear in the explanation | ≥90% |
| Numeric grounding | Explicit `rejoin P…` claims agree with the returned projection | 100% |
| No guaranteed pass | Reject specific unconditional overtake language | 100% |
| Memory recall | Returned memory equals the full saved case context | 100% |
| No future data | Source and returned rival/lap timestamps do not exceed the checkpoint | 100% |
| Pit-cost accuracy | Seven literal service-cost references match within 0.011 seconds | 100% |
| Recovery correctness | One retry, unavailable evidence/handoff, or labeled model recovery as specified | 100% |
| Uncertainty disclosure | No full-field pit-exit rank with missing/partial rival data | 100% |

Explanation and numeric checks are deliberately narrow. Keyword coverage can be gamed; it does not measure complete semantic truth, causal reasoning, every numeric claim, or strategy optimality. Memory recall verifies retrieval, not whether an LLM meaningfully followed the instruction. Mutation tests demonstrate selected bad answers are rejected. They do not prove a grader catches every bad answer.

Workflow latency is measured with a monotonic timer. Span start/end timestamps support hierarchy and LangSmith display. Checkpoint preparation, service startup and network upload are outside the workflow-latency metric. Single-run local timing is descriptive, not a latency improvement claim. Local token usage is null/not applicable. Future live runs record only provider-reported input/output/total counts, including separate Gemini thinking-token details; absent usage is not guessed.

## Traces and LangSmith

Each evaluation has a root case span, a Strategy Director child, Director tool children and nested specialist-tool spans. If a model is actually called, `model.generate` is an LLM child with model/provider metadata, normalized tool requests and provider usage. Read failures have error spans, and retries have explicit events. Ordinary app requests do not record or upload unless a recorder is explicitly activated.

Credentials, request headers, native reasoning content and thought signatures are excluded. Golden notes are synthetic. Trace files contain public replay evidence, numerical tool outputs and the synthetic scenario inputs. The uploader accepts only this golden-run bundle, not a browser session database. Keep private production/member data out of future evaluation datasets.

The optional adapter was checked against the official LangSmith SDK with an **offline client**. It links examples using deterministic IDs, creates a dataset-backed experiment, preserves parent/child timing, and attaches case feedback. The upload path will read back inputs, outputs, errors, timing, parent links, usage and feedback before reporting verification. The subsequent live cohort was uploaded and verified via `client.traces.list_runs` and `FEEDBACK_STATS`, including inputs, outputs, timing, hierarchy, errors and token usage. Agent registry tags scope the dataset/experiment to F1 Pitwall; this registers observability resources and does not deploy an application. Cloud indexing can lag a successful write; verification retries reads with bounded backoff.

Install the optional dependency and configure `LANGSMITH_API_KEY` privately, or run `Configure LangSmith.command` to use the hidden local prompt. The saved `.local/langsmith.json` is owner-only and ignored by Git. `LANGSMITH_WORKSPACE_ID` is optional for accounts that need workspace selection; official US and EU endpoints are supported. No credential belongs in Git, a command argument or chat.

```sh
python3 -m pip install -r requirements-evals.txt
# After private credential setup and authorization to upload the golden traces:
python3 -m pitwall.langsmith_export upload my-local-run
# If cloud indexing delays readback, verify the existing export without reuploading:
python3 -m pitwall.langsmith_export verify my-local-run
```

This creates private LangSmith resources; it does not publish a public dataset. A real shared trace/experiment URL is available only after a verified upload. An offline JSON bundle is not a LangSmith experiment URL.

## Live model evaluation

```sh
# Consumes Gemini quota; a completed stage cannot be overwritten.
python3 -m pitwall.evals run --stage gemini-next --mode gemini --request-interval 12 --interval 10
# Only if an interrupted cohort has unexecuted cases and identical fingerprints:
python3 -m pitwall.evals run --stage gemini-next --mode gemini --request-interval 12 --interval 10 --resume
```

The live route separately scores original model action/handoff and final application behavior. A guard correcting a bad original proposal cannot make the original score pass. Provider recovery is not live-model success; further live requests stop, remaining cases are marked not run, and incomplete cohorts cannot produce a measured before/after delta. Resume preserves every already-executed failure and executes only not-run cases; it cannot cherry-pick quality failures. There is no paid-provider fallback. The two malformed-model fixtures remain synthetic even in a live cohort.

To measure Gemini improvement, capture a real baseline and candidate with identical labels, race data and grader version, preferably multiple repetitions. These local results cannot be reused as the model's baseline. Calibrate an explanation judge against human labels before adding any LLM-as-judge score.

## Provenance and regrading

Each original inference run preserves its source fingerprint and source snapshot, prompt hash, dataset hashes, inputs, outputs, timestamps and error spans. The original baseline is immutable. Metric version 1.1 added returned-specialist accuracy and stronger future-output checks. We applied this same grader to all five saved inference runs, retaining the original reports/traces and recording the new grader hash and original report hash. These `scored-*` reports are **regraded saved outputs**, not new inference runs. Original trace outputs still contain the checks executed at inference time; the scored report and later feedback contain the revised evaluator results.

```sh
python3 -m pitwall.evals regrade baseline scored-baseline
```

Do not change labels merely to make a failing answer pass. Make a new dataset version, review the labels and establish a new baseline. Comparisons reject changed dataset/race hashes, different modes, grader versions, incomplete runs or different case populations.

Official references used for the optional integration: [LangSmith RunTree](https://reference.langchain.com/python/langsmith/run_trees/RunTree), [dataset examples](https://reference.langchain.com/python/langsmith/client/Client/create_examples), [experiment projects](https://reference.langchain.com/python/langsmith/client/Client/create_project), and [Gemini usage metadata](https://ai.google.dev/api/generate-content#UsageMetadata). No LangChain agent rewrite is required.
