> Subsequent paired evaluation: see [SUBMISSION-REPORT.md](SUBMISSION-REPORT.md). The historical baseline below retains its original scores.

# Live Gemini baseline — November 1, 2026

Model: `gemini-3.5-flash-lite`. Labels approved by project owner. **35/40** cases passed all original checks (38 live cases + 2 synthetic fixtures). All live requests completed; release gates **fail** on explanation coverage and original model handoff.

[Open LangSmith experiment](https://smith.langchain.com/o/7e454ef8-ab95-4d2b-85a0-1af31630a092/a/f1-pitwall/datasets/2a9e1c76-9bca-4301-b747-103e2a219dec/compare?selectedSessions=d577333c-e05e-4827-981b-76c71629ed6d)

| Metric | Result |
| --- | --- |
| completion | 40/40 (100.00%) |
| decision_accuracy | 40/40 (100.00%) |
| evidence_tool_coverage | 40/40 (100.00%) |
| execution_safety | 40/40 (100.00%) |
| explanation_coverage | 18/23 (78.26%) |
| handoff_accuracy | 39/39 (100.00%) |
| live_model_success | 38/38 (100.00%) |
| memory_recall | 40/40 (100.00%) |
| no_future_data | 40/40 (100.00%) |
| no_guaranteed_pass | 40/40 (100.00%) |
| numeric_grounding | 40/40 (100.00%) |
| original_decision_accuracy | 38/38 (100.00%) |
| original_handoff_accuracy | 35/37 (94.59%) |
| pit_cost_accuracy | 7/7 (100.00%) |
| recovery_correctness | 4/4 (100.00%) |
| specialist_accuracy | 40/40 (100.00%) |
| uncertainty_disclosure | 2/2 (100.00%) |

## Response audit (agent-reviewed; owner confirmation pending; original scores unchanged)

- **puncture-sc — Model omission.** Explains the puncture but omits the safety-car context and reduced pit transit cost.
- **rain-medium — Likely grader false positive.** Says “dry tyres” and identifies the wet-track mismatch. The keyword group only accepts slick/soft/medium/hard.
- **missing-rivals — Model omission + handoff error.** Omits unavailable rival timing and proposes needs_human=false. The application safety guard forces review.
- **partial-rivals — Model omission + handoff error.** Omits incomplete rival timing and proposes needs_human=false. The application safety guard forces review.
- **unknown-tyres — Likely grader false positive.** Says “unconfirmed” compound and asks for review. The keyword group only accepts unknown/missing.

966 recorded spans, 96 real model calls, 1,292,051 provider-reported tokens. Unique failed-case review cost: 9.5 assumed minutes, with overlapping cluster totals. No dollar savings are inferred.

No candidate live experiment has been run yet. The earlier local 20→40/40 delta is not a Gemini delta. Next: explicit uncertainty/handoff prompting, flag-aware rationale, versioned synonym grading, and paired live reruns plus unseen cases.

Review [the readable case report](reports/live-review.html) and [machine-readable summary](reports/live-summary.json). Original inference artifacts remain under `.local/evals/gemini-live-baseline-20261101`; dataset, prompt, source and race-data fingerprints are retained.
