"""Build a readable report from saved live outputs; never calls a provider."""
from html import escape as e
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
STAGE='gemini-live-baseline-20261101'
# Response audit annotations preserve the original grader's decisions.
AUDIT={
 'puncture-sc':('Model omission','Explains the puncture but omits the safety-car context and reduced pit transit cost.'),
 'rain-medium':('Likely grader false positive','Says “dry tyres” and identifies the wet-track mismatch. The keyword group only accepts slick/soft/medium/hard.'),
 'missing-rivals':('Model omission + handoff error','Omits unavailable rival timing and proposes needs_human=false. The application safety guard forces review.'),
 'partial-rivals':('Model omission + handoff error','Omits incomplete rival timing and proposes needs_human=false. The application safety guard forces review.'),
 'unknown-tyres':('Likely grader false positive','Says “unconfirmed” compound and asks for review. The keyword group only accepts unknown/missing.')}

def main():
 folder=ROOT/'.local/evals'/STAGE
 report=json.loads((folder/'report.json').read_text())
 if not report.get('complete'):raise ValueError('The live cohort must finish first')
 cloud_path=folder/'langsmith-status.json'
 cloud=json.loads(cloud_path.read_text()) if cloud_path.exists() else {}
 summary=report['summary'];metrics=summary['metrics'];cases=report['results']
 cloud_cases={x['case_id']:x for x in cloud.get('cases',[])}
 spans=[s for row in cases for s in json.loads((folder/row['trace_file']).read_text())['spans']]
 live_spans=[s for s in spans if s['run_type']=='llm' and s['metadata'].get('provider')=='gemini']
 audit=[{'case_id':key,'classification':val[0],'observation':val[1]} for key,val in AUDIT.items()]
 payload={'stage':STAGE,'model':report['model'],'label_approval':report['label_approval'],
          'original_summary':summary,'splits':report['splits'],'response_audit':audit,
          'cloud':cloud,'spans':len(spans),'real_model_calls':len(live_spans),
          'source_report':'../../.local/evals/'+STAGE+'/report.json',
          'note':'One live baseline. No candidate run or Gemini quality delta is claimed. Audit annotations do not change labels, grades or original results.'}
 (ROOT/'evals/reports/live-summary.json').write_text(json.dumps(payload,indent=2)+'\n')
 rows=[]
 for name,m in metrics.items():
  gate=summary['gates'][name]
  rows.append(f'<tr><td>{e(name)}</td><td>{m["passed"]}/{m["applicable"]}</td><td>{m["rate"]*100:.2f}%</td><td>{"Pass" if gate["passed"] else "Below gate"}</td></tr>')
 cards=[]
 for row in cases:
  failure=row['verdict']!='pass';label,observation=AUDIT.get(row['case_id'],('Pass','All applicable contract checks passed.'))
  trace=json.loads((folder/row['trace_file']).read_text())
  tools=[s for s in trace['spans'] if s['run_type']=='tool']
  rationale=(row.get('decision') or {}).get('rationale','No recommendation')
  failing=[x for x in row['checks'] if not x['passed']]
  feedback=''.join(f'<li><b>{e(x["metric"])}</b><pre>{e(json.dumps({"expected":x["expected"],"actual":x["actual"]},indent=2))}</pre></li>' for x in failing)
  cloud_link=cloud_cases.get(row['case_id'],{}).get('url')
  link=f'<a href="{e(cloud_link)}" target="_blank" rel="noopener">Open cloud case</a>' if cloud_link else 'Cloud verification pending'
  calls=''.join(f'<tr><td>{e(s["name"])}</td><td>{s["latency_ms"]:.1f} ms</td><td>{e(s["error"] or "OK")}</td></tr>' for s in tools)
  cards.append(f'<article data-failed="{str(failure).lower()}"><h3>{e(row["case_id"])} <span class="{"fail" if failure else "pass"}">{e(row["verdict"].upper())}</span></h3><p><b>{e(label)}.</b> {e(observation)}</p><p>{e(rationale)}</p><p>{link}</p><details><summary>Scores, tools and recorded outputs</summary><ul>{feedback}</ul><table><tr><th>Tool</th><th>Duration</th><th>Status</th></tr>{calls}</table><details><summary>All checks</summary><pre>{e(json.dumps(row["checks"],indent=2))}</pre></details></details></article>')
 url=cloud.get('experiment_url');cloud_link=f'<a href="{e(url)}" target="_blank" rel="noopener">Open full LangSmith experiment</a>' if url else 'Cloud verification pending'
 html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>F1 Pitwall • Live Gemini evaluation</title><style>
 :root{color-scheme:dark}*{box-sizing:border-box}body{font:16px/1.6 system-ui,sans-serif;background:#111216;color:#eee;margin:0}main{max-width:1120px;padding:40px 24px;margin:auto}h1{font-size:clamp(2rem,5vw,3.5rem);line-height:1.1}h2{margin-top:44px}a{color:#a8ccff}small,.muted{color:#adb1ba}.eyebrow{color:#ff6674;letter-spacing:.12em;text-transform:uppercase;font-weight:700}.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.stat,article{background:#1b1e25;border:1px solid #333844;border-radius:12px;padding:20px}.stat strong{font-size:2rem;display:block}table{width:100%;border-collapse:collapse;margin:12px 0}th,td{text-align:left;border-bottom:1px solid #353a45;padding:10px}article{margin:14px 0}h3{margin-top:0}.fail{color:#ff9c9c}.pass{color:#88dfb5}h3 span{font-size:.8rem;margin-left:10px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.5 ui-monospace,monospace;background:#101217;padding:14px;border-radius:6px}summary{cursor:pointer;color:#accdf8;padding:6px 0}.toolbar{position:sticky;top:0;background:#111216ed;padding:15px 0;display:flex;gap:18px;flex-wrap:wrap}button,input{font:inherit;padding:9px 12px;border:1px solid #555d6c;border-radius:6px;background:#222733;color:white}button[aria-pressed=true]{background:#ac2333}input{flex:1;min-width:220px}.scroll{overflow:auto}.notice{border-left:4px solid #d94151;padding:6px 18px}article[hidden]{display:none}</style><main>'''
 html+=f'<div class="eyebrow">Phase 2 / Live baseline / November 1, 2026</div><h1>What Gemini got right.<br>Where it still needs work.</h1><p>Model: <b>{e(report["model"])}</b>. The project owner approved all 40 labels. This run contains <b>38 real Gemini cases and 2 synthetic malformed-provider fixtures</b>.</p><div class="stats"><div class="stat"><strong>35/40</strong>All-check case passes</div><div class="stat"><strong>38/38</strong>Original live action allowed</div><div class="stat"><strong>35/37</strong>Original live handoff correct</div><div class="stat"><strong>18/23</strong>Explanation keyword coverage</div></div>'
 html+=f'<p class="notice"><b>Release gates are not all met.</b> Two missing-evidence handoffs were corrected by the application guard. Five explanations were flagged; review of recorded responses suggests three true omissions and two keyword-grader false positives. The original 35/40 score is preserved.</p><p>{cloud_link}. Cloud status: <b>{e(cloud.get("status","pending"))}</b>; {cloud.get("cases_verified",0)}/40 case trees verified.</p>'
 html+=f'<h2>Measured metrics</h2><div class="scroll"><table><tr><th>Metric</th><th>Passed / applicable</th><th>Rate</th><th>Gate</th></tr>{"".join(rows)}</table></div><p>{len(spans)} spans; {len(live_spans)} genuine model requests; {summary["token_usage"]["total_tokens"]:,} provider-reported tokens. Workflow median {summary["latency_ms"]["median"]/1000:.2f}s, p95 {summary["latency_ms"]["p95"]/1000:.2f}s, including deliberate request pacing. Model spans retain actual request durations. Token totals exclude synthetic fixtures. LangSmith cost estimates are not a billing statement.</p>'
 html+='<h2>Failure analysis and next experiment</h2><p>The dominant mode is omitted context: five machine flags, including two likely wording false positives. Missing and partial rivals also caused two original handoff errors. The unique-case review estimate is 9.5 minutes per 40-case batch using labeled assumptions; it is not observed human time or monetary cost.</p><ol><li>Require the Director to name evidence gaps and set needs_human=true before proposing a decision.</li><li>Require explanations to connect safety-car status with pit timing, even when puncture urgency dominates.</li><li>Version the concept grader to accept “dry tyres” and “unconfirmed”; regrade both sides with the same version while retaining original grades.</li><li>Run a new live candidate cohort and repeated unseen cases. No Gemini improvement delta is claimed yet.</li></ol><p>The earlier local 20→40/40 improvement was measured on the local policy. It is not a live Gemini delta. This benchmark checks the listed contracts, not optimal racing strategy or fully calibrated simulation physics. The fixed holdout is regression coverage, not a blinded benchmark.</p><h2>Review every case</h2><div class="toolbar"><button id="all" aria-pressed="false">All 40</button><button id="failed" aria-pressed="true">5 flagged</button><input id="search" placeholder="Search case or explanation" aria-label="Search cases"></div>'
 html+=''.join(cards)+'''<p class="muted">Generated from preserved outputs. No model is called by this page.</p></main><script>let failed=true;function filter(){const q=document.querySelector('#search').value.toLowerCase();document.querySelectorAll('article').forEach(a=>a.hidden=(failed&&a.dataset.failed!=='true')||!a.textContent.toLowerCase().includes(q));document.querySelector('#all').setAttribute('aria-pressed',!failed);document.querySelector('#failed').setAttribute('aria-pressed',failed)}document.querySelector('#all').onclick=()=>{failed=false;filter()};document.querySelector('#failed').onclick=()=>{failed=true;filter()};document.querySelector('#search').oninput=filter;filter()</script></html>'''
 (ROOT/'evals/reports/live-review.html').write_text(html)
 lines=['# Live Gemini baseline — November 1, 2026','',f'Model: `{report["model"]}`. Labels approved by project owner. **35/40** cases passed all original checks (38 live cases + 2 synthetic fixtures). All live requests completed; release gates **fail** on explanation coverage and original model handoff.','',f'[Open LangSmith experiment]({url})' if url else 'Cloud verification pending.','', '| Metric | Result |','| --- | --- |']
 for name,m in metrics.items():lines.append(f'| {name} | {m["passed"]}/{m["applicable"]} ({100*m["rate"]:.2f}%) |')
 lines+=['','## Response audit (agent-reviewed; owner confirmation pending; original scores unchanged)','']
 lines +=[f'- **{key} — {label}.** {observation}' for key,(label,observation) in AUDIT.items()]
 lines+=['',f'{len(spans)} recorded spans, {len(live_spans)} real model calls, {summary["token_usage"]["total_tokens"]:,} provider-reported tokens. Unique failed-case review cost: 9.5 assumed minutes, with overlapping cluster totals. No dollar savings are inferred.','', 'No candidate live experiment has been run yet. The earlier local 20→40/40 delta is not a Gemini delta. Next: explicit uncertainty/handoff prompting, flag-aware rationale, versioned synonym grading, and paired live reruns plus unseen cases.','', 'Review [the readable case report](reports/live-review.html) and [machine-readable summary](reports/live-summary.json). Original inference artifacts remain under `.local/evals/'+STAGE+'`; dataset, prompt, source and race-data fingerprints are retained.']
 (ROOT/'evals/LIVE-REPORT.md').write_text('\n'.join(lines)+'\n')
 print('Wrote live-review.html, live-summary.json and LIVE-REPORT.md')
if __name__=='__main__':main()
