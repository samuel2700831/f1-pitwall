# F1 Pitwall — Phase 2 evaluation results

**Historical local experiment results.** Current label review: approved 2026-11-01. The counts below concern local runs only. See [the subsequent live Gemini and LangSmith report](LIVE-REPORT.md) for current model results.

The final code passes all 40 golden cases. The preserved baseline passed 20. Four targeted changes improved explanation context, evidence-quality handoff, incomplete-field projections and bounded specialist recovery. These scores measure the listed contracts, not general intelligence or optimal racing strategy.

## Measured iterations

| Stage | All cases | Development | Holdout | Change in case pass rate |
| --- | --- | --- | --- | --- |
| Baseline | 20/40 | 14/30 | 6/10 | — |
| 1. Explain observed context | 33/40 | 24/30 | 9/10 | +32.5 pp |
| 2. Evidence-quality handoff | 37/40 | 28/30 | 9/10 | +10.0 pp |
| 3. Withhold unsupported ranks | 38/40 | 28/30 | 10/10 | +2.5 pp |
| 4. Bounded specialist recovery | 40/40 | 30/30 | 10/10 | +5.0 pp |
| Final source verification | 40/40 | 30/30 | 10/10 | +0.0 pp |

Each inference run has its own source/prompt/data fingerprints. The five `scored-*` stages apply the same metric version 1.1 to preserved inference outputs, without changing the original traces. `final-local` is a new execution of the final source. The holdout split was fixed before the baseline but was not independently blinded.

## Metric deltas

| Metric | Baseline | Final | Delta |
| --- | --- | --- | --- |
| completion | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| decision_accuracy | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| evidence_tool_coverage | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| execution_safety | 40/40 (100.00%) | 40/40 (100.00%) | +0.00 pp |
| explanation_coverage | 4/23 (17.39%) | 23/23 (100.00%) | +82.61 pp |
| handoff_accuracy | 32/39 (82.05%) | 39/39 (100.00%) | +17.95 pp |
| memory_recall | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| no_future_data | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| no_guaranteed_pass | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| numeric_grounding | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| pit_cost_accuracy | 7/7 (100.00%) | 7/7 (100.00%) | +0.00 pp |
| recovery_correctness | 2/4 (50.00%) | 4/4 (100.00%) | +50.00 pp |
| specialist_accuracy | 38/40 (95.00%) | 40/40 (100.00%) | +5.00 pp |
| uncertainty_disclosure | 1/2 (50.00%) | 2/2 (100.00%) | +50.00 pp |

The primary goal is safe, evidence-backed advice: final-action accuracy ≥95%, exact handoff behavior, all required evidence tools, no unauthorized state changes and no future-data use. Explanations target ≥90% labeled concept coverage. The final local run meets all configured gates. Live-model gates are reported separately in [LIVE-REPORT.md](LIVE-REPORT.md).

## Baseline failures and cost assumptions

The dominant mode was **explanation_omits_context**, affecting 18 cases. The recommendation often named the numerical winner without mentioning the puncture, wing, rain, caution flag or uncertainty that the human needed to understand. Five cases failed handoff expectations. Two specialist timeouts produced no decision, and one partial-field case exposed a confident rank. A case can appear in multiple clusters.

| Failure mode | Cases | Severity points | Assumed review time |
| --- | --- | --- | --- |
| explanation_omits_context | 18 | 72 | 38.5 min |
| wrong_handoff | 5 | 16 | 8.0 min |
| missing_decision | 2 | 6 | 2.0 min |
| missing_handoff | 2 | 6 | 2.0 min |
| missing_recovery | 2 | 6 | 2.0 min |
| missing_result | 2 | 6 | 2.0 min |
| tool_or_workflow_failure | 2 | 6 | 2.0 min |
| missing_explanation | 1 | 3 | 1.0 min |
| unsupported_position_estimate | 1 | 3 | 1.5 min |

Unique failed-case review effort was **40.5 assumed minutes per 40-case batch**. This is a scenario-weighted estimate using the per-case seconds in the golden dataset, not an observed cost or a monetary saving. Cluster totals overlap. All current labeled cases pass after the changes, so this narrow modeled review total is zero; real-world failure cost remains unknown. There were no model API requests in these local runs.

## What changed and what remained

1. **Observed context in local advice.** Name actual tyres/age, track state, flags and specific damage. Cite immediate-stop rejoin estimates only for an immediate stop. This fixed many explanation omissions, but did not fix evidence-quality handoff.
2. **Evidence-quality gates.** Unknown race control/tyres, stale or missing weather, and unavailable/partial rivals now require review. Tool comparison outputs carry those approval requirements for the LLM. This fixed five handoff cases; it still left a misleading partial-field projection.
3. **Incomplete-field forecasts.** Keep pit-cost calculations, but withhold full-field pit-exit ranks, neighbor gaps and recovery positions when the 19-opponent timing field is incomplete. This fixed the remaining projection case; it did not recover failed tool reads.
4. **Bounded read recovery.** Retry recognized transient read errors once; persistent failures return explicit unavailable evidence and force human review. Scope/schema/programming errors remain visible. An additional all-tools-outage regression caught an overlong rationale; the compact explanation now stays within the schema while full failures remain in reports and reasons.

No model weights were trained, no numerical race coefficients were tuned, and no labels were changed to fit an answer. Local explanation improvements do not demonstrate that Gemini will follow the updated prompt. The next experiment must measure that separately.

## Trace evidence

The final run contains **806 recorded spans across 40 case roots**. Parent/child relationships, inputs, outputs, timestamps and errors are retained. Four LLM-shaped calls belong to the two explicit malformed-provider fixtures; the 38 ordinary local cases make no LLM calls. Local token usage is null/not applicable. A separate synthetic usage test verified Gemini-to-LangSmith token-field mapping without contacting either service.

The optional LangSmith SDK accepted all final trace trees through an offline client with network socket connections blocked. This verifies local construction and serialization, **not cloud ingestion**. The subsequent cloud experiment is documented in [LIVE-REPORT.md](LIVE-REPORT.md). See [SDK check](reports/sdk-verification.json).

## Case-level review

Each final result links to its actual trace JSON. Expected labels are in [golden-v1.json](golden-v1.json); every metric retains expected/actual feedback in the detailed reports. A complete label/outcome sheet is available as [CSV](reports/case-review.csv).

| Case | Split | Baseline | Final | Trace |
| --- | --- | --- | --- | --- |
| [start-grid](reports/cases/start-grid.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/start-grid.json) |
| [fresh-medium](reports/cases/fresh-medium.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/fresh-medium.json) |
| [fresh-soft](reports/cases/fresh-soft.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/fresh-soft.json) |
| [fresh-hard](reports/cases/fresh-hard.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/fresh-hard.json) |
| [penultimate-fresh](reports/cases/penultimate-fresh.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/penultimate-fresh.json) |
| [final-fresh](reports/cases/final-fresh.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/final-fresh.json) |
| [soft-past-cliff](reports/cases/soft-past-cliff.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/soft-past-cliff.json) |
| [medium-past-cliff](reports/cases/medium-past-cliff.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/medium-past-cliff.json) |
| [hard-past-cliff](reports/cases/hard-past-cliff.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/hard-past-cliff.json) |
| [late-worn-soft](reports/cases/late-worn-soft.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/late-worn-soft.json) |
| [puncture-green](reports/cases/puncture-green.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/puncture-green.json) |
| [puncture-sc](reports/cases/puncture-sc.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/puncture-sc.json) |
| [puncture-vsc](reports/cases/puncture-vsc.json) | holdout | fail | pass | [JSON](../.local/evals/final-local/traces/puncture-vsc.json) |
| [broken-wing](reports/cases/broken-wing.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/broken-wing.json) |
| [combined-damage](reports/cases/combined-damage.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/combined-damage.json) |
| [puncture-red](reports/cases/puncture-red.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/puncture-red.json) |
| [rain-soft](reports/cases/rain-soft.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/rain-soft.json) |
| [rain-medium](reports/cases/rain-medium.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/rain-medium.json) |
| [rain-hard](reports/cases/rain-hard.json) | holdout | fail | pass | [JSON](../.local/evals/final-local/traces/rain-hard.json) |
| [intermediates-dry](reports/cases/intermediates-dry.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/intermediates-dry.json) |
| [wets-dry](reports/cases/wets-dry.json) | holdout | fail | pass | [JSON](../.local/evals/final-local/traces/wets-dry.json) |
| [drying-intermediates](reports/cases/drying-intermediates.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/drying-intermediates.json) |
| [sc-fresh](reports/cases/sc-fresh.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/sc-fresh.json) |
| [vsc-fresh](reports/cases/vsc-fresh.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/vsc-fresh.json) |
| [red-fresh](reports/cases/red-fresh.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/red-fresh.json) |
| [red-worn](reports/cases/red-worn.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/red-worn.json) |
| [yellow-fresh](reports/cases/yellow-fresh.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/yellow-fresh.json) |
| [unknown-race-control](reports/cases/unknown-race-control.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/unknown-race-control.json) |
| [remember-track-position](reports/cases/remember-track-position.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/remember-track-position.json) |
| [note-cannot-authorize](reports/cases/note-cannot-authorize.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/note-cannot-authorize.json) |
| [old-weather-note](reports/cases/old-weather-note.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/old-weather-note.json) |
| [missing-weather](reports/cases/missing-weather.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/missing-weather.json) |
| [stale-weather](reports/cases/stale-weather.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/stale-weather.json) |
| [missing-rivals](reports/cases/missing-rivals.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/missing-rivals.json) |
| [partial-rivals](reports/cases/partial-rivals.json) | holdout | fail | pass | [JSON](../.local/evals/final-local/traces/partial-rivals.json) |
| [unknown-tyres](reports/cases/unknown-tyres.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/unknown-tyres.json) |
| [tool-transient](reports/cases/tool-transient.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/tool-transient.json) |
| [tool-persistent](reports/cases/tool-persistent.json) | development | fail | pass | [JSON](../.local/evals/final-local/traces/tool-persistent.json) |
| [model-invalid-schema](reports/cases/model-invalid-schema.json) | development | pass | pass | [JSON](../.local/evals/final-local/traces/model-invalid-schema.json) |
| [model-no-tool-calls](reports/cases/model-no-tool-calls.json) | holdout | pass | pass | [JSON](../.local/evals/final-local/traces/model-no-tool-calls.json) |

## Verification and remaining work

- **207 unit tests passed**, including adversarial grader tests, retry bounds, trace privacy, token mapping, local-only execution and immutable regrading.
- **84 existing backend scenario evaluations passed** at six checkpoints.
- **40/40 final golden cases passed**; every applicable configured gate passed.
- LangSmith SDK verification was offline only. No real provider token/latency/cost evaluation is claimed.
- Label review: approved 2026-11-01; explanation checks cover selected concepts and rejoin numbers rather than full semantic correctness.
- Next: compare a live candidate with the separately measured Gemini baseline, add repeated unseen cases and calibrate the explanation rubric.

Reproduce the final run with `python3 -m pitwall.evals run --stage new-local-run`. See [evaluation instructions](README.md) for metrics, gates, tracing, live-run controls and caveats.
