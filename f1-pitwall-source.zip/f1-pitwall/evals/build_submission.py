"""Build the final paired submission from preserved outputs, never call an LLM."""
import argparse
from copy import deepcopy
from html import escape as esc
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from pitwall.evals import read_dataset,sha,compare_reports,save_report,comparison_inputs as normalized_inputs
BASE='gemini-baseline-paired-20261101'
CAND='gemini-candidate-paired-20261101'
OUT=ROOT/'evals/reports'



def load(stage):
    folder=ROOT/'.local/evals'/stage
    return folder,json.loads((folder/'report.json').read_text()),json.loads((folder/'langsmith-status.json').read_text())


def performance(report):
    real=[row for row in report['results'] if row['live_model_case']]
    times=sorted(row['latency_ms']/1000 for row in real)
    usage_complete=all(row.get('usage') is not None for row in real)
    return {'workflow_p95_seconds':times[math.ceil(len(times)*.95)-1],
            'workflow_median_seconds':statistics.median(times),
            'mean_total_tokens':statistics.mean(row['usage']['total_tokens'] for row in real) if usage_complete else None,
            'usage_complete':usage_complete,'live_cases':len(real),'fixture_cases':sum(row['provider_fixture'] for row in report['results']),
            'total_tokens':sum(row['usage']['total_tokens'] for row in real) if usage_complete else None}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline',default=BASE);parser.add_argument('--candidate',default=CAND)
    args=parser.parse_args()
    golden=read_dataset();contract=json.loads((ROOT/'evals/submission-metrics.json').read_text())
    bf,b,bc=load(args.baseline);cf,c,cc=load(args.candidate)
    if not b.get('complete') or not c.get('complete'):raise ValueError('Both live cohorts must finish')
    if not bc.get('verified') or not cc.get('verified'):raise ValueError('Both cloud exports must be verified')
    if b['grading_revision']['grader_sha256']!=c['source_sha256']['pitwall/evals.py']:
        raise ValueError('The actual scoring implementations differ')
    if c['submission_metrics_sha256']!=sha(contract):raise ValueError('Metric budgets changed after the candidate started')
    normalized=[]
    for report in (b,c):
        clone=deepcopy(report)
        for row in clone['results']:row['inputs']=normalized_inputs(row['inputs'])
        normalized.append(clone)
    comparison=compare_reports(*normalized)
    pa,pb=performance(b),performance(c)
    headlines=[]
    for spec in contract['metrics']:
        ident=spec['id']
        if ident in b['summary']['metrics']:
            x=b['summary']['metrics'][ident];y=c['summary']['metrics'][ident]
            before=x['passed']/x['applicable'];after=y['passed']/y['applicable']
            population=f'{x["applicable"]} applicable cases'
        else:
            before=pa[ident];after=pb[ident];population='38 genuine live cases'
        threshold=spec['threshold'];higher=spec['direction']=='at_least'
        passed=after is not None and (after>=threshold if higher else after<=threshold)
        headlines.append({**spec,'baseline':before,'candidate':after,'delta':after-before if after is not None and before is not None else None,
                          'candidate_passed':passed,'denominator_note':population})
    before={row['case_id']:row for row in b['results']};after={row['case_id']:row for row in c['results']}
    cloud_before={row['case_id']:row['url'] for row in bc['cases']};cloud_after={row['case_id']:row['url'] for row in cc['cases']}
    rows=[]
    for case in golden['cases']:
        ident=case['id'];a,z=before[ident],after[ident]
        assert normalized_inputs(a['inputs'])==normalized_inputs(z['inputs'])
        def observed(row):
            decision=row['decision'] or {}
            return {'original_proposal':decision.get('model_proposal'),
                    'final_decision':{k:decision.get(k) for k in ('recommended','needs_human','rationale','source')},
                    'verdict':row['verdict'],'checks':row['checks'],
                    'failure_categories':sorted({x['failure_mode'] for x in row['checks'] if not x['passed']}),
                    'latency_ms':row['latency_ms'],'usage':row['usage'],'error':row['error'],
                    'trace_id':row['trace_id'],'llm_calls':row['llm_calls']}
        astate,zstate=observed(a),observed(z)
        state='regressed' if a['verdict']=='pass' and z['verdict']=='fail' else 'improved' if a['verdict']=='fail' and z['verdict']=='pass' else 'unchanged'
        rows.append({'case_id':ident,'category':case['category'],'split':case['split'],
                     'provider_fixture':a['provider_fixture'],'live_model_case':a['live_model_case'],
                     'scenario_input':{k:case.get(k) for k in ('id','lap','branch','observed','memory','rival_mode','fault')},
                     'input':a['inputs'],'candidate_input':z['inputs'],'normalized_input_sha256':sha(normalized_inputs(a['inputs'])),
                     'expected_behavior':{k:case.get(k) for k in ('allowed_choices','needs_human','rationale_concepts','stop_loss','position_available','expected_recovery','label_reason')},
                     'baseline':astate,'candidate':zstate,'change':state,
                     'baseline_cloud':cloud_before[ident],'candidate_cloud':cloud_after[ident]})
    failures=[r for r in rows if r['candidate']['verdict']=='fail'];regressions=[r['case_id'] for r in rows if r['change']=='regressed']
    original=json.loads((ROOT/'.local/evals/gemini-live-baseline-20261101/report.json').read_text())
    scorer_fixes=[r['case_id'] for r in b['results'] if next(x for x in original['results'] if x['case_id']==r['case_id'])['verdict']=='fail' and r['verdict']=='pass']
    primary_ok=all(h['candidate_passed'] for h in headlines)
    payload={'baseline_stage':args.baseline,'candidate_stage':args.candidate,'validation_summary':json.loads((ROOT/'.local/validation/predeploy-summary.json').read_text()),
             'model':c['model'],'rubric_version':c['schema_version'],
             'dataset_sha256':b['dataset_sha256'],'prompt_versions':{'baseline':b['prompt_sha256'],'candidate':c['prompt_sha256']},
             'metric_contract':contract,'headlines':headlines,'baseline_performance':pa,'candidate_performance':pb,
             'baseline_summary':b['summary'],'candidate_summary':c['summary'],'comparison':comparison,
             'performance_regressions':[h['id'] for h in headlines if h['direction']=='at_most' and h['candidate'] is not None and h['candidate']>h['baseline']],
             'splits':{'baseline':b['splits'],'candidate':c['splits']},
             'regressions':regressions,'remaining_failures':[r['case_id'] for r in failures],
             'rubric_only_case_fixes':scorer_fixes,'legacy_baseline_passes':original['summary']['passed'],
             'paired_baseline_passes':b['summary']['passed'],'candidate_passes':c['summary']['passed'],
             'primary_gates_passed':primary_ok,'all_contract_gates_passed':c['summary']['gates_passed'],
             'release_gates_passed':primary_ok and c['summary']['gates_passed'],
             'input_comparison':'All case labels and substantive frozen inputs identical. Only car.telemetry.snapshot_id and nested telemetry read_at/called_at wall-clock bookkeeping are excluded from equality. Historical as_of, timing_at, last_lap_at, position_at and available_at remain compared.',
             'cloud':{'baseline':bc,'candidate':cc},'cases':rows}
    save_report(payload,OUT/'paired-results.json')
    def fmt(value,unit):
        if value is None:return 'unavailable'
        return f'{100*value:.2f}%' if unit=='fraction' else f'{value:,.2f}'
    metric_lines=['| Metric | Baseline | Improved | Delta | Pass bar | Improved passes |','| --- | --- | --- | --- | --- | --- |']
    for h in headlines:
        unit=h['unit'];delta=f'{h["delta"]*100:+.2f} pp' if unit=='fraction' else f'{h["delta"]:+,.2f}'
        bar=('≥' if h['direction']=='at_least' else '≤')+fmt(h['threshold'],unit)
        metric_lines.append(f'| {h["name"]} | {fmt(h["baseline"],unit)} | {fmt(h["candidate"],unit)} | {delta} | {bar} | {"Yes" if h["candidate_passed"] else "No"} |')
    changes=[
      ('Handoff priority in the Director prompt','Missing and partial rival data caused original needs_human=false. The prompt now prioritizes evidence gaps and explicitly copies the selected option’s approval flag before ordinary automatic hold rules.'),
      ('Constraints beside numerical options','compare_strategies now returns decision_constraints: current flags, reduced transit, active damage, tyre/weather mismatch, and evidence gaps. These are computed observations and rules, not stored scenario answers.'),
      ('Multi-trigger explanations','The prompt requires all critical coexisting context, including safety-car transit benefits alongside puncture urgency. It permits two to four concise sentences rather than forcing two.'),
      ('Versioned lexical rubric','Rubric 1.2.1 accepts domain synonyms and common noun plurals and uses term boundaries. Both cohorts use this exact scorer. Original 1.1 outputs and scores remain immutable; two baseline case fixes are grader-only, not model improvement.')]
    lines=['# F1 Pitwall evaluation submission','',
      '## Use case, agent and outcome','',
      'F1 Pitwall is an Austin 2025 historical-conditions strategy simulation for Charles Leclerc at Ferrari. The target user is a human strategy director who needs a timely, evidence-backed recommendation to stay out or consider a pit stop, with explicit uncertainty and human authorization before any stop. Rivals follow historical pace/stops; Leclerc follows simulated state and human decisions. The three deterministic specialists are Rival Analyst, Race Conditions & Incidents, and Leclerc Performance. A Gemini Strategy Director calls their tools, recalls saved intent, compares numerical strategies and submits a structured proposal.','',
      '**Evaluation one-liner:** '+contract['evaluation_one_liner'],'',
      '## Five primary metrics and scoring','',*metric_lines,'',
      'The first three metrics are binary per applicable case, aggregated as passed/applicable. Action correctness uses an owner-approved allowed set. Handoff correctness scores the original model proposal before application guards. Explanation coverage requires at least one term from every labeled concept group using the versioned lexical rubric. A case PASS means all its applicable contract checks pass, not a weighted average of the five headline metrics.','',
      'Latency is nearest-rank p95 across 38 genuine assessments, including the same 12-second minimum model-round pacing. Between-case waits, checkpoint preparation and LangSmith upload are excluded. Token budget is average provider-reported total tokens across all rounds per genuine case, with complete usage required. Tokens are a cost proxy; no monetary bill or savings claim is inferred. Budgets were defined after inspecting the baseline and before the candidate, as baseline-informed engineering targets.','',
      'Secondary hard guardrails separately check final-action safety, required evidence tools, exact specialist outputs, no future data, numeric grounding, no guaranteed overtakes, memory retrieval and bounded recovery. No LLM judge is used. Lexical coverage is narrower than semantic correctness; passing it does not prove every claim or strategy is optimal.','',
      '## Evaluator types','',
      '| Type | Implemented | Evidence |', '| --- | --- | --- |',
      '| Code-based | Yes | Executed deterministic quality, handoff, safety, numeric, latency/token-budget and recovery checks |',
      '| Trajectory | Yes, narrow workflow contracts | Required delegates/tools before proposal, bounded tool/model retries and budgets, no unauthorized state change, nested trace hierarchy. Not a semantic assessment of private reasoning. |',
      '| Human review | Expected labels approved; model-output ratings pending | Dataset approval is pinned to its hash. Workbook provides separate editable baseline/improved review fields. No response rating is fabricated. |',
      '| LLM-as-judge | No | No judge prompt/output or judge-vs-human agreement is claimed or required for this deterministic route. |', '',
      '## Golden dataset and identical-case design','',
      f'All 40 expected labels were approved by the owner and remain unchanged. There are 38 genuine Gemini cases plus two explicitly scripted malformed-provider recovery fixtures. The dataset contains 6 routine, 4 tyre-wear, 6 damage, 6 weather, 6 race-control, 3 memory, 5 evidence-quality and 4 recovery cases. Memory cases include a saved instruction that cannot authorize a stop and a stale-weather note that must not override current evidence. There are 30 development and 10 preassigned holdout cases. The holdout was visible during development and is not blinded.','',
      payload['input_comparison'],'',
      'Bundled race provenance is recorded in `data/austin-2025-source.json`: OpenF1 race session 9888 (meeting 1271, October 19, 2025), covering lap, stint, position, interval, pit, race-control and weather observations. The demo uses 56 historical laps. Test defaults and injected damage, weather and feed failures are simulated inputs, not claims about what happened on those laps. Historical driver pit stops do not authorize Leclerc’s simulated car to stop.','',
      f'Both live cohorts use `{c["model"]}`, the same dataset/replay hashes and the same rubric `{c["schema_version"]}` implementation hash. Prompt/source versions differ deliberately and are preserved in metadata and source snapshots.','',
      '## Results and measured delta','',
      f'The untouched original baseline scored {original["summary"]["passed"]}/40 with rubric 1.1. The same saved baseline outputs score **{b["summary"]["passed"]}/40** under 1.2.1. The live candidate scores **{c["summary"]["passed"]}/40** under that identical rubric: **{(c["summary"]["passed"]-b["summary"]["passed"])/40*100:+.1f} percentage points** in all-check case pass rate. Grader-only baseline fixes: '+', '.join(scorer_fixes)+'.','',
      'Primary headline gates: '+str(primary_ok)+'. All secondary contract gates: '+str(c['summary']['gates_passed'])+'. Combined release gates: '+str(payload['release_gates_passed'])+'.','',
      'Case regressions: '+(', '.join(regressions) or 'none observed in this paired run')+'. Remaining candidate failures: '+(', '.join(payload['remaining_failures']) or 'none in this 40-case cohort')+'.','',
      f'Performance tradeoffs: median checkpoint latency {pa["workflow_median_seconds"]:.2f}s → {pb["workflow_median_seconds"]:.2f}s ({pb["workflow_median_seconds"]-pa["workflow_median_seconds"]:+.2f}s). Mean tokens {pa["mean_total_tokens"]:,.2f} → {pb["mean_total_tokens"]:,.2f} ({(pb["mean_total_tokens"]/pa["mean_total_tokens"]-1)*100:+.2f}%). Higher-is-worse primary performance measures that regressed: '+(', '.join(payload['performance_regressions']) or 'none')+'. Passing a budget does not erase a regression.', '',
      '## Top three failure findings','',
      '1. **Decision-critical context omitted.** `puncture-sc` recommended a puncture stop but omitted safety-car context. The comparable baseline has three explanation failures: `puncture-sc`, `missing-rivals`, `partial-rivals`.','2. **Original human handoff wrong with incomplete rivals.** `missing-rivals` and `partial-rivals` proposed automatic hold. Application guards corrected both, but original-model scores remain failed.','3. **Evaluator rejected valid wording.** `rain-medium` said “dry tyres” and `unknown-tyres` said “unconfirmed.” Rubric 1.1 rejected these; the revised rubric accepts them for both runs. This is an evaluator failure, not a third fabricated model failure mode. Boundary/plural regressions are covered by automated tests.','',
      'Failure modes overlap. Costs use golden-case severity points and assumed review seconds, not observed human effort or money. Comparable baseline unique failed-case review effort: '+f'{b["summary"]["unique_failed_case_review_seconds"]/60:.1f} minutes; candidate: {c["summary"]["unique_failed_case_review_seconds"]/60:.1f} minutes. Cluster totals must not be summed as independent case counts.','',
      '## Four targeted changes','']
    lines += [f'{i}. **{name}.** {text}' for i,(name,text) in enumerate(changes,1)]
    lines+=['','The three agent changes were evaluated as one live candidate. This does not isolate each change’s causal contribution. Earlier local policy ablations measured 20→33→37→38→40/40; those results are separate and are not Gemini quality gains.','',
       '## Regressions, limits and next steps','',
       'The candidate includes every executed case, including errors and failures; no successful retry replaced a failed quality result. One paired run is not a statistical reliability claim. Tight handoff requirements are checked separately from application corrections. Specialist accuracy is tested against frozen source inputs, not an independent physical simulator. Memory scoring verifies retrieval, not full semantic obedience.','',
       'Next: repeat the paired live experiment across seeds/time windows, add unseen incomplete-feed and combined-hazard cases, inspect explanations with an owner-calibrated semantic rubric, and reduce duplicated tool evidence if latency/token budgets fail. Preserve the lexical rubric version and never tune expected labels to make a model answer pass.','',
       '## Supporting materials and reproduction','',
       'Automated verification passed 216 backend tests and 84 separate local scenario checks; the machine-readable predeploy summary is included in the review package. Code-based and trajectory checks are exercised by the backend tests; no unit-test count is a substitute for the paired live quality results.','',
       '- `golden-v1.json`, `label-approval.json`: unchanged cases and approval tied to the dataset hash.',
       '- `submission-metrics.json`: primary rubric, populations and numerical budgets.',
       '- `../pitwall/agents.py`: Director prompt, tool declarations, workflow and application guards.',
       '- `../pitwall/evals.py`: executable deterministic scorers, gates, fault injection, immutable regrading and run comparison.',
       '- `../pitwall/specialists.py`, `../pitwall/evidence_quality.py`, `../pitwall/gemini.py`, `../pitwall/langsmith_export.py`: specialist tools, quality rules, provider adapter and trace export/readback.',
       '- `../tests/test_phase2_evals.py`, `../tests/test_live_evals_setup.py`, `../tests/test_submission_evals.py`: adversarial grading and recovery/export regressions.',
       '- `reports/paired-results.json`: full inputs, expected behaviors, both outputs, all checks, failures, hashes and links for every case. A spreadsheet and browser-readable report accompany it.',
       '', '```sh', 'python3 -m unittest discover -s tests',
       'python3 -m pitwall.evals regrade gemini-live-baseline-20261101 new-baseline-rubric',
       'python3 -m pitwall.evals run --stage new-candidate --mode gemini --request-interval 12 --interval 10',
       'python3 -m pitwall.langsmith_export upload new-baseline-rubric',
       'python3 -m pitwall.langsmith_export upload new-candidate',
       'python3 evals/build_submission.py --baseline new-baseline-rubric --candidate new-candidate', '```', '',
       'Original inference/source artifacts are included in the review evidence archive. Private browser races and credential files are excluded.','',
       '## LangSmith evidence','',
       f'- [Comparable baseline]({bc["experiment_url"]}): {bc["cases_verified"]} cases and {bc["spans_verified"]} spans verified.',
       f'- [Improved experiment]({cc["experiment_url"]}): {cc["cases_verified"]} cases and {cc["spans_verified"]} spans verified.',
       'Both exports preserve actual recorded timing, nested model/tool calls, normalized usage, errors, case IDs, original prompt/source fingerprints and effective scoring versions. Regraded baseline trace outputs retain their original checks; current rubric scores are separate LangSmith feedback and grading-revision metadata. Workspace links require account access. The offline report and evidence package provide review without LangSmith credentials.','']
    for label,report,perf,folder in [('Baseline',b,pa,bf),('Candidate',c,pb,cf)]:
        spans=[s for row in report['results'] for s in json.loads((folder/row['trace_file']).read_text())['spans']]
        llm=[s for s in spans if s['run_type']=='llm' and s['metadata'].get('provider')=='gemini']
        vals=sorted(s['latency_ms']/1000 for s in llm)
        lines.append(f'{label}: {len(llm)} genuine model calls, {perf["total_tokens"]:,} provider-reported tokens; model-request latency median {statistics.median(vals):.2f}s, nearest-rank p95 {vals[math.ceil(len(vals)*.95)-1]:.2f}s (pacing excluded).')
    (ROOT/'evals/SUBMISSION-REPORT.md').write_text('\n'.join(lines)+'\n')
    metric_html=''.join('<tr>'+''.join('<td>'+esc(col.strip())+'</td>' for col in line.strip('|').split('|'))+'</tr>' for line in metric_lines if not line.startswith('| ---'))
    cards=[]
    for row in rows:
        expected=row['expected_behavior'];parts=[]
        for key,label in [('baseline','Baseline'),('candidate','Improved')]:
            result=row[key];proposal=result['original_proposal'] or result['final_decision']
            parts.append(f'<section><h4>{label}: {esc(result["verdict"].upper())}</h4><p><b>{esc(str(proposal.get("choice",proposal.get("recommended"))))}</b> · human review: {esc(str(proposal.get("needs_human")))}</p><p>{esc(proposal.get("rationale") or "No rationale")}</p><p>Failed checks: {esc(", ".join(x["metric"] for x in result["checks"] if not x["passed"]) or "none")}</p><a href="{esc(row[key+"_cloud"])}">Open {label.lower()} trace</a></section>')
        cards.append(f'<article data-state="{esc(row["change"])}"><h3>{esc(row["case_id"])} <small>{esc(row["change"])}</small></h3><p>{esc(expected["label_reason"])}</p><p>Expected choices: {esc(str(expected["allowed_choices"]))}; human review: {esc(str(expected["needs_human"]))}. {"Synthetic provider fixture" if row["provider_fixture"] else "Genuine Gemini case"}.</p><div class="pair">{"".join(parts)}</div><details><summary>Full input, labels and scored evidence</summary><pre>{esc(json.dumps(row,indent=2))}</pre></details></article>')
    # Report body is also plain text so the standalone page needs no CDN or Markdown library.
    body='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>F1 Pitwall paired evaluation</title><style>*{box-sizing:border-box}body{font:16px/1.6 system-ui;background:#f4f5f7;color:#171b23;margin:0}main{max-width:1250px;margin:auto;padding:32px 24px}h1{font-size:2.5rem;line-height:1.15}h2{margin-top:36px}a{color:#a0152b}table{border-collapse:collapse;width:100%;background:white}td{padding:12px;border-bottom:1px solid #ddd}tr:first-child{font-weight:700;color:white;background:#202632}article{background:white;border:1px solid #d4d8de;border-left:4px solid #c52238;border-radius:8px;padding:22px;margin:18px 0}h3{margin-top:0}small{font-weight:400;color:#596273}.pair{display:grid;grid-template-columns:1fr 1fr;gap:24px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.6 ui-monospace,monospace;background:#eef0f4;padding:18px}summary{cursor:pointer;color:#982033;padding:10px 0}.tools{position:sticky;top:0;background:#f4f5f7ee;padding:12px 0;display:flex;gap:12px;flex-wrap:wrap}input,select{padding:10px;font:inherit;border:1px solid #999;border-radius:5px}input{flex:1}article[hidden]{display:none}.scroll{overflow:auto}@media(max-width:750px){.pair{grid-template-columns:1fr}}</style><main>'''
    body+=f'<h1>F1 Pitwall: baseline and improved agent</h1><p>Same 40 golden cases · {esc(c["model"])} · rubric {esc(c["schema_version"])} · 38 live cases and 2 synthetic recovery fixtures per run.</p><p><b>{b["summary"]["passed"]}/40 → {c["summary"]["passed"]}/40</b> all-check passes using the same grader. Original legacy baseline: {original["summary"]["passed"]}/40. Combined release gates: <b>{"PASS" if payload["release_gates_passed"] else "NOT MET"}</b>.</p><div class="scroll"><table>{metric_html}</table></div><p>Regressions: {esc(", ".join(regressions) or "none observed")}. Remaining failed cases: {esc(", ".join(payload["remaining_failures"]) or "none in this cohort")}.</p><p><a href="{esc(bc["experiment_url"])}">LangSmith baseline</a> · <a href="{esc(cc["experiment_url"])}">LangSmith improved</a> · <a href="paired-results.json">Complete scored JSON</a></p><details><summary>Full evaluation report, rubric, failure analysis and next steps</summary><pre>{esc(chr(10).join(lines))}</pre></details><h2>All 40 scored cases</h2><div class="tools"><input id="q" placeholder="Search case, output or failure" aria-label="Search cases"><select id="state" aria-label="Filter changes"><option value="all">All 40 cases</option><option value="improved">Improved cases</option><option value="regressed">Regressions</option><option value="failed">Remaining failures</option></select></div>'+''.join(cards)
    body+='''</main><script>const q=document.querySelector('#q'),s=document.querySelector('#state');function f(){document.querySelectorAll('article').forEach(a=>a.hidden=!a.textContent.toLowerCase().includes(q.value.toLowerCase())||(s.value==='improved'&&a.dataset.state!=='improved')||(s.value==='regressed'&&a.dataset.state!=='regressed')||(s.value==='failed'&&!a.querySelector('.pair section:last-child h4').textContent.includes('FAIL')))}q.oninput=f;s.onchange=f;</script></html>'''
    (OUT/'submission-review.html').write_text(body)
    print(json.dumps({'baseline':b['summary']['passed'],'candidate':c['summary']['passed'],'regressions':regressions,'remaining_failures':payload['remaining_failures'],'release_gates_passed':payload['release_gates_passed']},indent=2))

if __name__=='__main__':main()
