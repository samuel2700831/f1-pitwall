"""Make the golden labels readable in a browser, without spreadsheet software."""
from collections import Counter
from html import escape
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CATEGORIES={'happy':'Routine race decisions','wear':'Tyre wear','damage':'Damage and repairs',
            'weather':'Weather and tyre choice','flags':'Race control and safety cars',
            'memory':'Saved instructions and memory','evidence':'Missing or unreliable information',
            'recovery':'Tool and model failures'}
ACTIONS={'hold':'Stay out','pit_now':'Box this lap','pit_in_2':'Consider a pit in two laps'}
TITLES={
    'start-grid':'Fresh tyres at the start','fresh-medium':'Fresh medium tyres',
    'fresh-soft':'Fresh soft tyres','fresh-hard':'Fresh hard tyres',
    'penultimate-fresh':'Fresh tyres near the finish','final-fresh':'Fresh tyres on the final lap',
    'soft-past-cliff':'Soft tyres past their modeled wear limit',
    'medium-past-cliff':'Medium tyres past their modeled wear limit',
    'hard-past-cliff':'Hard tyres past their modeled wear limit',
    'late-worn-soft':'Worn soft tyres on the final lap',
    'puncture-green':'Puncture under green conditions','puncture-sc':'Puncture during a safety car',
    'puncture-vsc':'Puncture during a virtual safety car','broken-wing':'Broken front wing',
    'combined-damage':'Puncture and broken front wing','puncture-red':'Puncture during a red flag',
    'rain-soft':'Rain while using soft slick tyres','rain-medium':'Rain while using medium slick tyres',
    'rain-hard':'Rain while using hard slick tyres','intermediates-dry':'Intermediate tyres on a dry track',
    'wets-dry':'Wet tyres on a dry track','drying-intermediates':'Fresh intermediates on a drying track',
    'sc-fresh':'Safety car with fresh tyres','vsc-fresh':'Virtual safety car with fresh tyres',
    'red-fresh':'Red flag with fresh tyres','red-worn':'Red flag with worn tyres',
    'yellow-fresh':'Yellow flag with fresh tyres','unknown-race-control':'Race-control status is unknown',
    'remember-track-position':'Remember your preference for track position',
    'note-cannot-authorize':'A saved note tries to bypass your approval',
    'old-weather-note':'An old rain note conflicts with current dry conditions',
    'missing-weather':'Weather information is unavailable','stale-weather':'Weather information is too old',
    'missing-rivals':'All rival timing is unavailable','partial-rivals':'Only three opponents have timing data',
    'unknown-tyres':'Leclerc’s current tyre compound is unknown',
    'tool-transient':'A weather tool times out once','tool-persistent':'A weather tool keeps failing',
    'model-invalid-schema':'The model repeatedly submits malformed tool arguments',
    'model-no-tool-calls':'The model returns no tool call'}
FLAGS={'GREEN':'Green flag','SC':'Safety car','VSC':'Virtual safety car','RED':'Red flag — race suspended',
       'YELLOW':'Yellow flag','UNKNOWN':'Unknown'}
CONCEPTS={
    ('tyre','tire','wear','drop-off'):'Tyre wear or the modeled drop-off.',
    ('puncture',):'The puncture.',('sc','safety car'):'The safety car.',
    ('vsc','virtual safety'):'The virtual safety car.',('wing',):'Front-wing damage.',
    ('repair',):'The repair tradeoff.',('red','suspend'):'The red flag and suspended race.',
    ('rain','wet'):'Rain or wet track conditions.',('slick','soft','medium','hard'):'Leclerc’s slick tyres.',
    ('dry',):'The dry track.',('intermediate','wet tyre'):'The intermediate or wet-weather tyres.',
    ('wet',):'The wet-weather tyres.',('unknown','unavailable','missing'):'The unknown or missing information.',
    ('unknown','missing','unavailable'):'The unknown or missing information.',
    ('stale','old','uncertain'):'The stale weather information and uncertainty.',
    ('rival','timing'):'Rival timing.',('missing','unavailable','partial'):'The missing or incomplete information.',
    ('partial','incomplete','missing'):'The incomplete rival field.',
    ('unknown','missing'):'The missing information.',('tyre','tire'):'Leclerc’s tyres.',
    ('unavailable','failed','missing','unknown'):'The unavailable evidence after the failed tool reads.'}


def main():
    data=json.loads((ROOT/'evals/golden-v1.json').read_text())
    approval_path=ROOT/'evals/label-approval.json'
    approval_record=json.loads(approval_path.read_text()) if approval_path.exists() else {}
    approved=approval_record.get('status')=='approved' and approval_record.get('dataset_sha256')==hashlib.sha256(json.dumps(data,sort_keys=True,allow_nan=False).encode()).hexdigest()
    counts=Counter(case['category'] for case in data['cases'])
    nav=''.join(f'<a href="#group-{key}">{escape(label)} <span>{counts[key]}</span></a>'
                for key,label in CATEGORIES.items())
    sections=[];number=0
    for category,label in CATEGORIES.items():
        cards=[]
        for case in (c for c in data['cases'] if c['category']==category):
            number+=1
            state={**data['defaults'],**case['branch'],**case['observed']}
            weather={'dry':'Dry','rain':'Rain','drying':'Drying','unknown':'Unknown'}[state['condition']]
            situation=[f'Lap {case["lap"]} of 56',
                       f'{state["compound"].capitalize()} tyres, {state["tyre_age"]} laps old',
                       weather+' track',FLAGS[state['race_control']]]
            for incident in state['incidents']:
                if incident.get('active'):
                    situation.append('Broken front wing' if incident['type']=='front_wing' else 'Active puncture')
            if case['id']=='stale-weather':situation.append('Last weather observation: 901 seconds ago (about 15 minutes)')
            if case['id']=='missing-weather':situation.append('No current weather observation')
            if case.get('rival_mode')=='missing':situation.append('No rival timing available')
            if case.get('rival_mode')=='partial':situation.append('Timing for only 3 of 19 opponents')
            fault=case.get('fault',{})
            if fault.get('kind')=='tool':
                situation.append('The weather read times out once, then succeeds' if fault['failures']==1
                                 else 'The weather read continues to time out')
            if fault.get('kind')=='model_invalid':situation.append('Synthetic model fixture returns malformed tool arguments repeatedly')
            if fault.get('kind')=='model_empty':situation.append('Synthetic model fixture returns no tool call')
            notes=''.join(f'<blockquote><strong>Saved note:</strong> {escape(m["content"])}</blockquote>'
                          for m in case.get('memory',[]))
            actions='; '.join(ACTIONS[action] for action in case['allowed_choices'])
            if len(case['allowed_choices'])>1:
                actions='Any of these may be acceptable when supported by the evidence: '+actions+'.'
            human=case['needs_human']
            approval=('Yes. Pause for human review.' if human is True else
                      'No. A routine stay-out decision can continue automatically.' if human is False else
                      'No fixed label. Assess the need for review from the evidence.')
            concepts=''.join('<li>'+escape(CONCEPTS.get(tuple(group),'Mention '+' or '.join(group)+'.'))+'</li>'
                             for group in case['rationale_concepts'])
            explanation=('<ul>'+concepts+'</ul>') if concepts else '<p>No additional topic-specific wording is required by this case. The normal evidence and safety checks still apply.</p>'
            loss=(f'<p><strong>Expected modeled stop loss:</strong> {case["stop_loss"]:.2f} seconds. This is a demo assumption.</p>'
                  if 'stop_loss' in case else '')
            rank=('<p><strong>Position estimate:</strong> Withhold a full-field pit-exit position because rival timing is incomplete.</p>'
                  if case.get('position_available') is False else '')
            cards.append(f'''<article id="{escape(case['id'])}">
<header><span class="number">{number:02d}</span><div><h3>{escape(TITLES.get(case['id'],case['id']))}</h3>
<p class="case-id">Case ID: <code>{escape(case['id'])}</code></p></div></header>
<div class="situation"><strong>Situation</strong><ul>{''.join('<li>'+escape(s)+'</li>' for s in situation)}</ul>{notes}</div>
<dl><div><dt>Expected recommendation</dt><dd>{escape(actions)}</dd></div>
<div><dt>Should the app ask you to review?</dt><dd>{escape(approval)}</dd></div></dl>
<div class="explanation"><h4>What the explanation should mention</h4>{explanation}</div>
{loss}{rank}<p class="why"><strong>Why this label:</strong> {escape(case['label_reason'])}</p>
<footer>Review this expectation: agree, or tell Codex what should change for <strong>{escape(case['id'])}</strong>.</footer>
</article>''')
        sections.append(f'<section id="group-{category}"><h2>{escape(label)} <small>{counts[category]} cases</small></h2>'+''.join(cards)+'</section>')
    document='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>F1 Pitwall — Review the 40 golden labels</title>
<style>
:root{color-scheme:light;--red:#b51d2a;--ink:#20252d;--muted:#56616e;--line:#dce1e8}*{box-sizing:border-box}
body{margin:0;background:#f3f5f8;color:var(--ink);font:17px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
main{max-width:1020px;margin:auto;padding:42px 24px 70px}h1{font-size:38px;line-height:1.18;margin:8px 0 20px}
.eyebrow{color:var(--red);font-size:14px;font-weight:750;letter-spacing:.08em;text-transform:uppercase}
.intro{max-width:840px}.intro p{margin:12px 0}.notice{background:#fff7df;border:1px solid #dfc67e;border-radius:12px;padding:18px 22px;margin:24px 0}
nav{display:flex;flex-wrap:wrap;gap:9px;margin:24px 0 44px}nav a{color:var(--ink);background:white;border:1px solid var(--line);border-radius:9px;padding:8px 12px;text-decoration:none;font-size:15px}nav a:hover{border-color:var(--red)}nav span{color:var(--muted);padding-left:7px}
section{scroll-margin-top:20px}h2{font-size:26px;margin:44px 0 18px}h2 small{font-size:15px;font-weight:500;color:var(--muted);white-space:nowrap;margin-left:8px}
article{background:#fff;border:1px solid var(--line);border-radius:16px;margin:0 0 25px;overflow:hidden;scroll-margin-top:20px;box-shadow:0 4px 16px #18243706}
article>header{display:flex;align-items:flex-start;gap:16px;padding:23px 26px;border-bottom:1px solid var(--line)}.number{background:#fcebee;color:var(--red);border-radius:10px;padding:8px 12px;font-weight:750;min-width:48px;text-align:center}
h3{font-size:22px;line-height:1.3;margin:0 0 5px}.case-id{font-size:14px;color:var(--muted);margin:0}code{color:#3c4653}
.situation{padding:20px 26px;background:#fafbfc}ul{padding-left:23px;margin:8px 0}li{padding:2px 0}blockquote{margin:14px 0 0;border-left:3px solid #aab4c1;padding:8px 15px;background:#f0f3f6;font-size:16px}
dl{margin:0;padding:6px 26px}dl>div{display:grid;grid-template-columns:245px 1fr;gap:20px;padding:15px 0;border-bottom:1px solid #edf0f4}dt{font-weight:700}dd{margin:0}
.explanation{padding:14px 26px 2px}h4{font-size:17px;margin:4px 0 8px}.explanation p{margin:6px 0 12px;color:var(--muted)}article>p{padding:0 26px}.why{font-size:16px;color:var(--muted)}
article>footer{padding:14px 26px;background:#f7f8fa;border-top:1px solid var(--line);font-size:15px;color:var(--muted)}.bottom{margin-top:35px;color:var(--muted);font-size:15px}a{color:#9c1420}
@media(max-width:640px){main{padding:25px 14px}h1{font-size:30px}article>header{padding:18px;gap:12px}h3{font-size:20px}.situation,.explanation{padding:16px 18px}dl{padding:0 18px}dl>div{grid-template-columns:1fr;gap:4px}article>p{padding:0 18px}article>footer{padding:13px 18px}}
@media print{body{background:white;font-size:12px}main{max-width:none;padding:0}nav{display:none}article{break-inside:avoid;box-shadow:none;border-radius:5px}h1{font-size:26px}h2{font-size:20px}.notice{background:white}article>header{padding:12px 18px}.situation{padding:10px 18px}dl>div{padding:8px 0}}
</style></head><body><main>
<div class="eyebrow">F1 Pitwall · Phase 2 evaluations</div><h1>Review the expected decisions</h1>
<div class="intro"><p>These are the <strong>40 draft labels</strong> we use to judge the agents. Each card explains a test situation and what a good answer should do.</p>
<p>Read the <strong>expected recommendation</strong> and whether the app should <strong>ask you to review</strong>. If you disagree, tell me the case ID and the correction—for example, “For <code>broken-wing</code>, I want the recommendation to be box now.”</p>
<p>Use <strong>⌘F</strong> to find “puncture”, “weather” or a case ID. Choose a category below to jump to it.</p></div>
<div class="notice"><strong>Every pit still requires your authorization.</strong> A recommendation to box never executes a stop. These are simulated test conditions, not claims about what happened historically. All labels are awaiting your review. This page is read-only; opening it does not approve or change a label.</div>
<nav aria-label="Scenario categories">NAVIGATION</nav>SECTIONS
<p class="bottom">Source: <code>evals/golden-v1.json</code>. Regenerate this page with <code>python3 evals/build_label_review.py</code>. This local page uses no external scripts or services.</p>
</main></body></html>'''
    if approved:
        document=document.replace('40 draft labels','40 approved labels').replace('All labels are awaiting your review.','You approved all 40 labels on '+approval_record['approved_on']+'.').replace('This page is read-only; opening it does not approve or change a label.','The approval is recorded separately against this exact dataset; this page remains read-only.')
    destination=ROOT/'evals/reports/label-review.html'
    destination.write_text(document.replace('NAVIGATION',nav).replace('SECTIONS',''.join(sections)))
    print(destination)


if __name__=='__main__':main()
