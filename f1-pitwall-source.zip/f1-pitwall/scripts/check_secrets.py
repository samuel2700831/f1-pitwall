"""Fail-closed local secret scan. Never prints matched text or credential values."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

VERSION = '8.30.1'


def scan(scanner, mode, target, temporary):
    if not target.is_dir():
        raise RuntimeError('Scan target is unavailable; publication blocked.')
    report = temporary / (mode + '-findings.json')
    # Explicit configuration prevents repository allowlists/environment variables
    # from silently disabling the standard scanner rules.
    config = temporary / 'default.toml'
    config.write_text('[extend]\nuseDefault = true\n')
    ignore = temporary / 'empty.gitleaksignore'
    ignore.write_text('')
    args = [scanner, mode, str(target), '--config', str(config),
            '--gitleaks-ignore-path', str(ignore),
            '--ignore-gitleaks-allow', '--redact=100', '--max-archive-depth=10',
            '--max-decode-depth=5', '--report-format=json',
            '--report-path', str(report), '--no-banner', '--no-color']
    if mode == 'git':
        args += ['--log-opts=--all --full-history']
    # Logs are kept private, even though Gitleaks is instructed to redact them.
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode not in (0, 1) or not report.is_file():
        raise RuntimeError('Secret scanner did not complete; publication blocked.')
    findings = json.loads(report.read_text()) or []
    if result.returncode == 1 and not findings:
        raise RuntimeError('Secret scanner failed without findings; publication blocked.')
    return {'mode': mode, 'target': str(target), 'passed': result.returncode == 0 and not findings,
            'findings': [{'file': item.get('File'), 'rule': item.get('RuleID'),
                          'commit': item.get('Commit'), 'line': item.get('StartLine')}
                         for item in findings]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scanner', default='gitleaks')
    parser.add_argument('--repository', type=Path)
    parser.add_argument('--directory', type=Path,
                        help='Prepared public files only; do not target private credential storage.')
    parser.add_argument('--summary', type=Path)
    args = parser.parse_args()
    if not (args.repository or args.directory):
        parser.error('Provide --repository and/or --directory')
    scanner = shutil.which(args.scanner)
    if not scanner:
        parser.error('Gitleaks is required; publication blocked. See SECURITY.md.')
    try:
        version = subprocess.check_output([scanner, 'version'], text=True).strip()
        if version.lstrip('v') != VERSION:
            raise RuntimeError('Use the pinned Gitleaks version ' + VERSION + '.')
        with tempfile.TemporaryDirectory(prefix='pitwall-secret-scan-') as directory:
            temporary = Path(directory)
            temporary.chmod(0o700)
            results = [scan(scanner, mode, target.resolve(), temporary)
                       for mode, target in [('git', args.repository), ('dir', args.directory)]
                       if target is not None]
        summary = {'scanner': 'gitleaks', 'version': VERSION,
                   'passed': all(item['passed'] for item in results), 'checks': results}
        if args.summary:
            args.summary.write_text(json.dumps(summary, indent=2) + '\n')
            os.chmod(args.summary, 0o600)
        print(json.dumps(summary, indent=2))
        return 0 if summary['passed'] else 1
    except (OSError, ValueError, subprocess.SubprocessError, RuntimeError):
        print('Security check could not complete; publication blocked. No credential values logged.')
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
